# Local verification record

## MySQL-only revision — 2026-11-25

The current runtime, schema setup, test fixtures, and CI use MySQL/MariaDB only. Alternative database code/schema was removed; existing legacy data files and private MySQL configuration were preserved. The deterministic scheduler was not changed. Results in earlier dated sections describe earlier revisions and are not new test runs.

| Check actually run | Observed result |
| --- | --- |
| PHP syntax | 56 local PHP files passed `php -l`, including the root entry point and ignored local configuration |
| `php tests/run.php --unit-only` | 41 passed, 0 failed; scheduling, UTC date arithmetic, input/output safety, and mounted URL behavior |
| Read-only `scripts/diagnose.php` | Passed: MariaDB 10.4.32, PDO MySQL, UTC, utf8mb4, six InnoDB tables |
| `php tests/run.php` | 95 passed, 0 failed, using an isolated temporary MySQL schema |
| `php tests/http.php` | 87 passed, 0 failed, using an isolated temporary schema and server |
| `php tests/http.php --subdirectory` | 90 passed, 0 failed; links, assets, redirects, forms, and cookies preserve `/BrainLoop/` |
| `php tests/apache-copy.php` | 32 passed, 0 failed on actual XAMPP Apache; fresh setup, scoped database account, registration, CRUD, review, analytics, and logout |
| Browser review | About/photo/footer, dashboard, deck/card forms, reveal/review/results, and analytics checked; representative layouts inspected at 375, 768, 1024, and 1440 pixels without page overflow |
| Team photograph | Original and project asset SHA-256 hashes match; all four people display without cropping or assigning names to faces |
| Installed copy update | Changed source files backed up outside htdocs; private configuration and runtime data preserved |

Initial provisioning was blocked by MariaDB Aria checksum error 176 in the shared `mysql.db` permission table. After the user approved continuing with the proposed backed-up repair, the table checked OK and required BrainLoop/phpMyAdmin grants were restored. Corrupted historical database-level privilege rows could not be recovered; the exact backup, scope, and limits are recorded in [MYSQL_RECOVERY_NOTE.md](MYSQL_RECOVERY_NOTE.md). BrainLoop's ordinary InnoDB data was preserved. Existing Apache and MySQL services were left running.

The added integration assertions now pass for native prepared statements, UTC/utf8mb4/strict settings, six InnoDB tables, Unicode/emoji persistence, malformed settings, owner-checked imports, valid study modes, and review retry keys bound to the same owner/card. A strict boolean assertion was corrected to accept PDO's disabled emulation value of integer zero. The partial-session HTTP assertion now checks the actual saved count and unfinished status instead of outdated decorative wording.

Browser verification used its own temporary MySQL schema, learner, and local server; all owned fixtures were removed afterward. The normal application database received no browser test account or sample study records. The screenshot at `docs/screenshots/about-team-updated.jpg` shows the real installed About page.

The final report was rendered with Poppler and visually reviewed page by page. It distinguishes the planned September 15–December 8 schedule and class acceptance from checks actually run on November 25. Responsibility details formalize contribution areas supplied by the team; no historical hours, commits, or meetings are asserted.

```powershell
php tests/run.php --unit-only
php scripts/diagnose.php
php tests/run.php
php tests/http.php
php tests/http.php --subdirectory
```

The first command deliberately excludes database integration; it does not use an alternative database or mask server failures. The configured CI pipeline provisions a separate MariaDB service, but no hosted GitHub Actions run is claimed here.

## Drop-in XAMPP subdirectory support — 2026-11-20

Verified locally with PHP 8.2.12, SQLite, and XAMPP MariaDB 10.4.32. The new root `index.php` and mount-aware URL helpers support the complete project at `/BrainLoop/`; no nested `public/` URL is required.

| Check | Observed result |
| --- | --- |
| URL, scheduler, model, and database suite — SQLite | 82 passed, 0 failed |
| URL, scheduler, model, and database suite — MariaDB | 82 passed, 0 failed |
| HTTP suite at hostname root — SQLite | 87 passed, 0 failed |
| HTTP suite at hostname root — MariaDB | 87 passed, 0 failed |
| HTTP suite mounted at `/BrainLoop/` — SQLite | 90 passed, 0 failed |
| HTTP suite mounted at `/BrainLoop/` — MariaDB | 90 passed, 0 failed |
| Mounted entry point | `/BrainLoop/index.php` rendered successfully |
| Mounted links and redirects | Actual rendered anchor/asset URLs and authentication/study redirects retained `/BrainLoop` |
| Routing helper boundaries | Hostname-root/nested mount detection, query strings, fragments, unsafe URL rejection, index routing, and mount-boundary stripping passed |
| Rendered link crawl | Each HTTP mode inspected 24 public/private pages and 34 local targets; no scripts or event handlers found |
| Actual Apache fresh-copy integration | `php tests/apache-copy.php`: 32 passed, 0 failed |
| Existing installed copy | `http://localhost/BrainLoop/` and `/BrainLoop/index.php` returned 200; CSS/assets returned 200 |
| Actual private-path protection | Installed private configuration and fresh-copy private paths, including direct `/public/` entry access, returned 403 |
| Fresh-copy browser setup | Local setup/CSRF/validation checks passed; private configuration and six database tables created; repeat setup disabled |
| Actual Apache application flow | Registration, deck/card creation, answer withholding/reveal, rating, analytics, and logout passed with mounted URLs and persisted MySQL review data |
| Updating the installed copy | Source files updated with a backup; existing private configuration and normal data preserved |

The HTTP subdirectory suites use a fixture router to exercise the real root entry point with `SCRIPT_NAME=/BrainLoop/index.php`. The separate 32-check Apache suite verified actual rewrite rules and first-run installation using its own fresh disposable `htdocs` copy, database, and user. All owned fixtures were removed afterward; normal installed data and credentials were preserved. Apache/MySQL were already running user services and were left running.

The installed root entry point was also checked in the browser at `http://localhost/BrainLoop/index.php`; its screenshot is saved locally as `docs/screenshots/htdocs-index.jpg`. CSS asset URLs now include a file-version query to refresh changed styling, and the narrow mobile hero layout was corrected during browser review. The screenshot is a local verification artifact and is ignored by Git by default.

```powershell
php tests/run.php
php tests/run.php --mysql
php tests/http.php
php tests/http.php --mysql
php tests/http.php --subdirectory
php tests/http.php --mysql --subdirectory
php tests/apache-copy.php
```

The final command is optional and requires actual local XAMPP Apache/MySQL; it is not a GitHub CI check. The configured CI matrix has not been executed on GitHub during this task. Oracle MySQL and production HTTPS hosting remain outside the locally verified scope.

## MySQL/MariaDB conversion — 2026-11-19

Verified locally with **PHP 8.2.12**, **MariaDB 10.4.32 from XAMPP**, and PDO MySQL. MySQL/MariaDB is now the default application backend; SQLite is an explicit alternative. No public production deployment or hosted GitHub Actions run is claimed.

| Check | Observed result |
| --- | --- |
| XAMPP database provisioning | Database and tables initialized; dedicated scoped user/password saved in ignored private configuration without printing credentials |
| PHP syntax | 48 local PHP files passed `php -l` (including the ignored local configuration) |
| MySQL/MariaDB model/database suite | 73 passed, 0 failed |
| MySQL/MariaDB HTTP suite | 87 passed, 0 failed |
| Optional SQLite model/database suite | 73 passed, 0 failed |
| Optional SQLite HTTP suite | 87 passed, 0 failed |
| Rendered routes/assets | Each HTTP mode inspected 24 public/private pages and 34 local targets; favicon delivered; no rendered scripts/event handlers |
| Apache virtual host | Configuration validation passed; `http://brainloop.localhost` returned 200 |
| Existing localhost site | Original `http://localhost` remained available with HTTP 200 |
| Private configuration over Apache | `/app/config.local.php` returned 404 |
| Browser flow on actual XAMPP Apache | Logged in, revealed and rated a card, and viewed completion; MySQL stored the Good rating and a one-day next interval |
| Normal MySQL data after verification | Only the temporary verification account was removed; the normal database is empty and ready for registration |
| Existing SQLite data | Original SQLite file retained; no automatic cross-engine copying performed |

The model and HTTP suites use randomly named temporary schemas and scoped test users for MariaDB; they do not use the application's normal database. The test schemas/users were dropped after completion. SQLite tests use memory/temporary files and leave the original SQLite data untouched.

The actual Apache browser check used a separately identified temporary account, which was removed after confirming the persisted review. Its screenshot is saved locally as `docs/screenshots/mysql-xampp-result.jpg`. Apache and MySQL were started for verification and stopped afterward; start both using the XAMPP Control Panel to use `http://brainloop.localhost`.

Run both database modes using the isolated harness:

```powershell
php tests/run.php
php tests/http.php
php tests/run.php --mysql
php tests/http.php --mysql
```

The default commands explicitly choose isolated SQLite. `--mysql` creates a fresh randomly named test database and random scoped user using separate administrator test credentials, then drops only the database/user it created. Normal application accounts and data are excluded from fixtures. The MySQL-specific local runs used XAMPP's MariaDB implementation; Oracle MySQL and production HTTPS hosting were not exercised. The CI matrix is configured for PHP 8.2/8.3/8.4 with a MariaDB service but has not been run on GitHub during this work.

## Original SQLite/browser verification — 2026-11-18

Verified on **2026-11-18** in the requested Windows project directory with **PHP 8.2.12**, PDO SQLite, and the ChatGPT in-app browser.

| Check | Observed result |
| --- | --- |
| Database initialization | `php scripts/setup.php` succeeded; setup is idempotent |
| PHP syntax | All 44 PHP files passed `php -l` |
| Scheduler, model, database, security helpers | 73 tests passed, 0 failed |
| HTTP functional and security suite | 87 checks passed, 0 failed |
| Internal links and assets | 24 rendered pages inspected; 34 local targets passed |
| Frontend restrictions | No JavaScript/TypeScript source files; rendered-page tests found no scripts or event handlers |
| Responsive layouts | 21 page states exercised at 375, 768, 1024, and 1440 pixels; identified overflow was corrected and affected states rechecked |
| Authentication layouts | Login and registration checked at all four widths without horizontal page overflow |
| Long content | A 117-character unbroken title, long subject, 2,000-character question, and 5,000-character answer exercised; final deck view fit all four widths |
| Keyboard study flow | Revealed and rated three sample cards using Enter; progress advanced and the completion screen displayed the actual saved rating distribution |
| Normal application data | Normal database retained empty, with no default account or sample reviews |

The HTTP suite covers registration, duplicate email rejection, session regeneration, login failures and throttling, logout, protected routes, deck/card CRUD and ownership, answer withholding, reveal, ratings, stale and duplicate submissions, due filtering, practice preserving schedules, partial session exit, analytics, search escaping, account updates, password changes, CSV import validation and formula-safe export, sample seeding, and cascading deletion.

Screenshots under `docs/screenshots/` show the real local interface and optional, explicitly labeled sample decks. Dashboard and analytics screenshots reflect three reviews actually performed during browser verification. The temporary preview database and its test account were removed, and the development preview server was stopped. Screenshots are ignored by Git by default; review and intentionally add selected images if using them in a public portfolio.

## Scope limits

- Verification used the installed PHP 8.2.12 runtime. The configured GitHub Actions PHP 8.2/8.3/8.4 matrix has not been executed on GitHub during this task.
- Apache/Nginx production hosting, HTTPS termination, and public deployment were documented but not exercised locally.
- Keyboard operation, selected text contrast, semantic labels, responsive behavior, and reduced-motion CSS were checked; this is not a formal WCAG conformance certification or independent security audit.
- The original development preview server was stopped. Follow the current README commands for XAMPP MySQL/MariaDB setup and local hosting.

Run verification again with:

```powershell
php tests/run.php
php tests/http.php
```
