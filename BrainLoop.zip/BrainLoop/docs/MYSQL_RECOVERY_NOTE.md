# Local XAMPP permission table recovery

Date: 25 November 2026.

The local XAMPP MariaDB 10.4.32 server reported Aria checksum error 176 in its shared `mysql.db` database-permission table. This prevented normal application access and new database grants. `mysql.global_priv` and `mysql.tables_priv` checked OK. BrainLoop's InnoDB records were not the damaged tables.

Before repair, the original `db.frm`, `db.MAI`, and `db.MAD` files were copied to `C:\xampp\mysql\brainloop-repair-backups\20261125-173930`. A SHA-256 manifest verified the copies. This private backup is outside htdocs and outside the source repository.

Following approval to continue with the proposed repair, an index-only repair was attempted first. The data file still failed its checksum check, so a standard table repair was required. The final `CHECK TABLE mysql.db` returned OK.

The corrupted database-level privilege rows could not be recovered by the repair. All five existing account identities in `mysql.global_priv` remained. The application-specific BrainLoop grant was restored from the existing private configuration, and the configured phpMyAdmin control account regained SELECT, INSERT, UPDATE, and DELETE access to its own `phpmyadmin` database. Unknown or orphaned historical test-database grants were not reconstructed.

An administrator should retain the original backup and review it if additional historical database-level permissions are needed. No BrainLoop user, deck, card, progress, or history table was deleted or repaired. The ordinary application connection subsequently passed the read-only diagnosis checks for UTC, utf8mb4, and all six InnoDB tables.

Repair procedures are server administration tasks, not actions performed automatically by BrainLoop. See the official [MariaDB REPAIR TABLE reference](https://mariadb.com/docs/server/reference/sql-statements/table-statements/repair-table) and [CHECK TABLE reference](https://mariadb.com/docs/server/reference/sql-statements/table-statements/check-table) before administering another installation.
