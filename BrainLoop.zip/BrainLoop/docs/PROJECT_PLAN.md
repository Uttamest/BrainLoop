# BrainLoop Planned Project Schedule

Baseline: 15 September to 8 December 2026. All dates below are planned targets, not a historical completion log.

| Planned dates | Phase | Deliverable | Responsibility |
| --- | --- | --- | --- |
| 15 to 21 Sep | Initiation and feasibility | Problem statement, objectives, scope, team agreement | Uttam; all members review |
| 22 to 28 Sep | Requirements | User stories, FR/NFR baseline, acceptance cases | Uttam and Shraddha; team review |
| 29 Sep to 5 Oct | Analysis and modeling | Use cases, context/interaction models, draft data model | Uttam and Suraj |
| 6 to 12 Oct | Architecture and design | Layer boundaries, MySQL schema, wireframes, style system | Uttam, Manisha, Suraj |
| 13 to 19 Oct | Foundation increment | Routes, public pages, registration/login, protected shell | Uttam and Suraj; Manisha styles |
| 20 to 26 Oct | Content increment | Deck/card CRUD, owner constraints, form feedback | Uttam and Suraj; Shraddha tests |
| 27 Oct to 2 Nov | Study increment | Reveal flow, ratings, scheduler, results, retry protection | Uttam; Suraj/Manisha interface; Shraddha tests |
| 3 to 9 Nov | Progress and exchange | Analytics, search, settings, CSV import/export | Uttam and Suraj; Shraddha tests |
| 10 to 16 Nov | System integration | MySQL configuration, htdocs routing, setup, security review | Uttam and Shraddha |
| 17 to 23 Nov | Quality refinement | Responsive interface, accessible labels, negative regression | Manisha, Suraj, Shraddha |
| 24 to 30 Nov | Documentation and acceptance preparation | Report, traceability, actual test record, team review | Uttam leads; all supply evidence |
| 1 to 7 Dec | Release and rehearsal | Feature freeze, clean-PC trial, backups, slides/demo rehearsal | All members; Uttam integrates |
| 8 Dec | Presentation and submission | Present, demonstrate, answer questions, submit approved package | All members |

![Planned timeline](assets/planned-timeline.svg)

Presentation and submission: **8 December 2026**. Planned rehearsal and release freeze: **1 to 7 December 2026**.