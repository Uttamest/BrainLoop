# BrainLoop Team Contributions

Primary contribution areas were supplied by the team. Detailed module responsibility and review allocation are described in the project report; no individual hours, commit totals, or completion dates are invented.

| Member | Student ID | Role | Contribution area |
| --- | --- | --- | --- |
| SHRESTHA UTTAM | 20244110 | Team Leader | Overall coordination and cross-module work, with primary responsibility for backend development, MySQL integration, GitHub workflow, and documentation. |
| THAPA MANISHA | 20244114 | Team Member | CSS and visual design, including the design system, layout, responsive styling, and interface consistency. |
| B K SURAJ | 20244108 | Team Member | Frontend development, including semantic HTML, page templates, forms, navigation, and frontend integration. |
| KHAND THAKURI SHRADDHA | 20244122 | Team Member | Testing and quality assurance, including functional scenarios, validation, regression checks, and defect reporting. |
