# Deploying BrainLoop

BrainLoop requires a PHP-capable server. GitHub is source hosting; GitHub Pages cannot run the PHP application. This repository does not configure a public host or claim a live deployment.

## Runtime and files

Use PHP 8.2+ with PDO and `pdo_mysql`; deploy a current supported security release. The application and tests use MySQL/MariaDB with InnoDB and utf8mb4. Use MySQL 8.0.16+ or MariaDB 10.4+ so database CHECK constraints are enforced. No Composer, Node.js, asset build, external API, or JavaScript runtime is needed.

For the local XAMPP drop-in layout, copy the whole project into `C:\xampp\htdocs\BrainLoop` and use its root `index.php` and `.htaccess`. The root rewrite rules must remain enabled: they block private application/configuration/storage paths and route assets safely. Do not enable directory listings or remove those protections.

For a dedicated production host, prefer pointing its document root directly at **`public/`** so application code, private configuration, scripts, tests, and Git metadata remain outside the public root. Both layouts use the same application and database; no source relocation into `public/` is necessary.

Environment variables:

```text
BRAINLOOP_ENV=production
BRAINLOOP_DB_DRIVER=mysql
BRAINLOOP_DB_HOST=127.0.0.1
BRAINLOOP_DB_PORT=3306
BRAINLOOP_DB_NAME=brainloop
BRAINLOOP_DB_USER=brainloop
BRAINLOOP_DB_PASSWORD=YOUR_PRIVATE_DATABASE_PASSWORD
BRAINLOOP_HTTPS=1
```

Use the actual host and private credential. `.env.example` documents the names; the project does not parse `.env` files. Supply values through your web server, PHP-FPM pool, hosting control panel, or process manager. Alternatively, an ignored `app/config.local.php` can return private overrides; real environment variables take precedence. Keep credentials out of Git and application output.

Create a dedicated database and database account scoped to it. Run `php scripts/setup.php` with the same database environment as the web process. Migration is idempotent and does not clear user data. If a trusted setup identity can create databases, `php scripts/setup.php --create-database` can create the configured database first. Never grant the normal application global database-administrator privileges. Allow the schema initialization operations required by the supplied setup/front controller within its own database. Do not make unrelated source files writable by the web process.

## XAMPP on this Windows machine

The working source remains at `C:\Users\acer\OneDrive\Desktop\BrainLoop`. To run the normal drop-in XAMPP layout, copy the complete folder to `C:\xampp\htdocs\BrainLoop`, start Apache/MySQL in the XAMPP Control Panel, and open [http://localhost/BrainLoop/](http://localhost/BrainLoop/) or [http://localhost/BrainLoop/index.php](http://localhost/BrainLoop/index.php).

The folder root contains the entry point; do not add another nested `BrainLoop` directory or browse through `/BrainLoop/public/`. The application detects `/BrainLoop` and keeps that prefix in links, forms, assets, redirects, and session cookies. No virtual host or hosts-file modification is required.

On a fresh local copy without private database configuration, use the database setup screen. Its administrator password is blank only when the local XAMPP database actually uses that default. Setup creates a random scoped application account and saves only that account's credentials. Preserve any existing `app/config.local.php` when updating an installed copy. MySQL records stay on the database server and are not replaced by copying source. XAMPP's MySQL service may be MariaDB, which is supported. The README also provides a manual phpMyAdmin schema-import and scoped-user alternative.

For CLI provisioning instead of the first-run screen:

```powershell
cd "C:\xampp\htdocs\BrainLoop"
$env:Path = "C:\xampp\php;" + $env:Path
php scripts/setup-xampp.php
php scripts/setup.php
```

`setup-xampp.php` connects using the local XAMPP administrator credentials, creates the `brainloop` database and a dedicated generated database user, and saves the random application password in the ignored `app/config.local.php`. It does not print the password or overwrite an existing local configuration. Supply `BRAINLOOP_ADMIN_DB_USER` / `BRAINLOOP_ADMIN_DB_PASSWORD` privately if the local administrator credentials differ from XAMPP's default `root`/empty password. This provisioning helper is for local setup; use your host's secure database provisioning procedure in production.

Keep Apache/MySQL running while using [http://localhost/BrainLoop/](http://localhost/BrainLoop/). Stop the services through the XAMPP Control Panel when they are no longer needed.

### Optional separate virtual host

The existing Desktop-based virtual-host alternative is still available at [http://brainloop.localhost](http://brainloop.localhost). It is optional and does not replace the normal `localhost/BrainLoop/` layout. To configure it:

```powershell
cd "C:\Users\acer\OneDrive\Desktop\BrainLoop"
powershell -ExecutionPolicy Bypass -File .\scripts\setup-apache.ps1
```

The script defaults to `C:\xampp` (override with `-XamppPath`), backs up `httpd-vhosts.conf`, preserves an existing localhost/default site, adds the BrainLoop virtual host once, validates it, and restores its backup if Apache rejects the result. Restart Apache after configuration changes. `scripts/xampp-vhost.conf` is the manual reference. Its document root and matching `<Directory>` point directly to the Desktop project's `public/` folder with local-only access. Do not expose the entire OneDrive/Desktop tree as a document root.

For an alternative development server while keeping the same MySQL backend:

```powershell
php -S localhost:8000 -t public public/router.php
```

Open [http://localhost:8000](http://localhost:8000) and stop that development process with Ctrl+C. It is not a production service.

## Apache

Enable PHP and `mod_rewrite`, set `DocumentRoot` to `/absolute/path/BrainLoop/public`, and allow the supplied `.htaccess` rewrite rules (typically `AllowOverride FileInfo Options`). Permit `Require all granted` for the public directory only. Disable directory indexes. If your host forbids `.htaccess`, copy its rules into the virtual-host configuration.

The app supports both a hostname-root installation and a subdirectory such as `/BrainLoop/`. Its front controller detects the mount path and shared URL helpers preserve it. When using the project-root drop-in layout, the root `.htaccess` is mandatory; when using a dedicated `public/` document root, use `public/.htaccess` instead.

## Nginx with PHP-FPM

Use the correct PHP-FPM socket or upstream for the host. A representative location policy is:

```nginx
root /srv/BrainLoop/public;
index index.php;

location / {
    try_files $uri $uri/ /index.php?$query_string;
}

location = /index.php {
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME $document_root/index.php;
    fastcgi_pass unix:/run/php/php-fpm.sock;
}

location ~ \.php$ { return 404; }
location ~ /\. { deny all; }
```

Adjust paths and the socket to the installation. Deny PHP execution for uploaded content if future features add uploads; BrainLoop's CSV import does not retain uploaded files in the public tree.

## HTTPS and errors

Serve login and all authenticated pages over HTTPS. Direct HTTPS is detected from the web server. Behind trusted TLS termination, set `BRAINLOOP_HTTPS=1` in trusted server configuration so sessions use Secure cookies. Do not set it during ordinary HTTP localhost development. Session cookies are HttpOnly and SameSite=Lax, and authenticated sessions regenerate their IDs.

Disable public PHP error display, enable error logging to a private destination, and restrict log access. BrainLoop's web bootstrap disables displayed errors. Monitor your host's error log and available disk space. Keep session files outside the public tree and configure appropriate expiration/cleanup on the host.

The built-in PHP server is a development convenience and must not be exposed as a production service.

## Backups and database portability

The database contains account data, password hashes, private study material, and review history. Back it up with access controls and a retention policy suitable to that data. Test restores to a separate database before relying on a backup. MySQL/MariaDB data is managed by its server, not stored in this source directory.

Use the database server's consistent dump/backup tooling and a scoped backup identity. For InnoDB, a properly configured transactional dump avoids partial snapshots of active writes. Protect both dumps and restore credentials. Do not copy a running MySQL/MariaDB data directory as a substitute for a tested backup procedure. Do not commit SQL dumps or database files to Git, put them in `public/`, or share unprotected download links.

The runtime supports MySQL only. Legacy local database files from earlier versions are preserved and ignored by Git, but are not opened or converted by this version. Any historical-data migration requires its own backed-up, validated process.

The README provides a PowerShell `mysqldump` command using `-p` for a private password prompt and `--result-file` to avoid shell output encoding changes. Restore into a separate database first, assign it a scoped account, and verify user ownership, review history, due dates, and analytics before changing a live connection. Keep application source, configuration backup, and data backup as separate artifacts.

## Before releasing

Run the automated suite and syntax checks, create a real account, exercise the functional checklist in `docs/TESTING.md`, verify ownership isolation with two accounts, and confirm no source/storage files can be fetched over HTTP. Ensure sample decks are deliberate and no fixed-password accounts exist. Check current runtime security patches and verify the backup/restore process for the actual host.
