# BrainLoop review scheduling

The service in `app/services/Scheduler.php` is a transparent, deterministic, simplified **SM-2-inspired** scheduler. It does not claim to implement official SM-2. It makes no scientific guarantee about retention.

## Stored state

Every new card gets a `card_progress` record: state `new`, due now, interval 0 days, ease 2.5, repetition count 0, and total reviews 0. `due_at` and `last_reviewed_at` are persisted as UTC `Y-m-d H:i:s` timestamps.

`repetition_count` is the number of consecutive successful scheduled reviews since the most recent Again rating. `total_reviews` counts scheduled reviews only. Practice is logged separately in review history and leaves the complete schedule untouched.

## Exact transition rules

Let `I` be the prior interval in days, `E` the pre-review ease factor clamped to `[1.3, 3.0]`, and `R` the prior repetition count. Valid ratings are lowercase `again`, `hard`, `good`, and `easy`; any other rating is rejected.

| Rating | When `R = 0` | When `R = 1` | When `R >= 2` | Ease after review |
| --- | --- | --- | --- | --- |
| Again | 10 minutes | 10 minutes | 10 minutes | `max(1.3, E - 0.20)` |
| Hard | 1 day | `max(I + 1, 3)` days | `max(I + 1, ceil(I × 1.2))` days | `max(1.3, E - 0.15)` |
| Good | 1 day | `max(I + 1, 6)` days | `max(I + 1, ceil(I × E))` days | `E` |
| Easy | 4 days | `max(I + 1, 8)` days | `max(I + 1, ceil(I × E × 1.3))` days | `min(3.0, E + 0.15)` |

For a successful rating, round the resulting interval up to a whole day, enforce at least one day, and cap it at 36,500 days. This cap prevents unbounded date growth. Ease is rounded to two decimal places after its change. The multiplier uses the **prior** ease, not the updated value.

Again sets state to `relearning`, resets repetitions to 0, and stores `interval_days = 10 / 1440`. All successful ratings set state `review` and increment repetitions. Every scheduled rating increments total reviews and records the rating and UTC review time. The next due time is the actual review time plus the resulting interval, never the previous due time.

The `I + 1` minimum prevents a changed rating from shrinking a successful interval. For example, Easy on a new card gives 4 days; a following Hard gives 5 days rather than 3. After Again, the next successful rating intentionally restarts the early steps.

## Worked examples

At `2026-11-18 12:00:00 UTC`, a new card rated Again is due at `12:10:00 UTC` that day. Hard and Good are due on November 19; Easy is due on November 22.

Repeated Good ratings, each submitted when due, produce intervals of **1, 6, 15, 38** days with ease 2.5. A lapse then produces the ten-minute step and resets consecutive successes. Exact values are tested with a fixed clock; elapsed wall time cannot change those tests.

## Due sessions and practice

A due card satisfies `due_at <= current UTC time`. Future cards are omitted from due-only selection and checked again when a scheduled review is saved. A session freezes a queue of at most 200 eligible card IDs, each presented once. Again does not immediately loop the same card; start another due session after its ten-minute step.

Intentional practice can include future-due cards. It saves a history row with `is_practice = 1`, and equal before/after interval values. It never changes due time, repetition count, ease, review state, total scheduled reviews, or last scheduled review fields.

Scheduled review update and history insertion are one database transaction. A unique submission key and session nonce prevent accidental double credit. Every submitted card is checked against the authenticated owner.

## Analytics policy

- UTC is used for storage, display, daily activity buckets, and streak dates.
- Total reviews and rating distribution include scheduled and practice history.
- Cards reviewed today is the number of distinct card IDs reviewed on today's UTC date.
- The dashboard review snapshot counts cards with a scheduled review today whose due date is still in the future. Its denominator is that count plus cards due now; practice does not inflate it. The sets are disjoint and the snapshot changes as cards become due.
- Streaks count distinct UTC calendar days with any saved review. Reviews on a single day do not multiply the streak.
- The current streak may end today or yesterday. If neither contains a review, it is zero.
- Longest streak is the largest run of consecutive recorded UTC dates.
- Daily activity displays fourteen UTC dates, with genuine zeros for inactive days.
- Deck progress is the percentage of its cards in state `review` with an interval of at least 21 days. This is an application indicator, not a measured retention score.
- Deleting cards/decks cascades through their histories. Statistics reflect the data still present.

Run `php tests/run.php` to check all ratings, repeated and mixed ratings, bounds, timezone conversion, due predicates, practice preservation, transaction behavior, and streak consistency.
