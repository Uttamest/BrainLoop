<?php
declare(strict_types=1);

/** Optional real-XAMPP integration check. Start Apache and MySQL before running it. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$sourceRoot = dirname(__DIR__);
$htdocs = realpath((getenv('BRAINLOOP_TEST_XAMPP_PATH') ?: 'C:/xampp') . '/htdocs');
if (!$htdocs) { fwrite(STDERR, "XAMPP htdocs was not found. Set BRAINLOOP_TEST_XAMPP_PATH if needed.\n"); exit(1); }
$suffix = bin2hex(random_bytes(6));
$fixtureName = 'BrainLoop-setup-check-' . $suffix;
$fixtureRoot = $htdocs . DIRECTORY_SEPARATOR . $fixtureName;
$base = '/' . $fixtureName;
$database = 'brainloop_setup_' . $suffix;
$cookies = []; $passed = 0; $pdo = null; $private = null; $exitCode = 0;
$adminUser = getenv('BRAINLOOP_TEST_DB_USER') ?: 'root';
$adminPassword = getenv('BRAINLOOP_TEST_DB_PASSWORD');
$adminPassword = $adminPassword === false ? '' : $adminPassword;
$port = getenv('BRAINLOOP_TEST_DB_PORT') ?: '3306';
$admin = new PDO('mysql:host=127.0.0.1;port=' . (int) $port . ';charset=utf8mb4', $adminUser, $adminPassword, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

function copyFixture(string $from, string $to, string $relative = ''): void
{
    if (!is_dir($to)) { mkdir($to, 0700, true); }
    foreach (new DirectoryIterator($from) as $entry) {
        if ($entry->isDot() || $entry->isLink()) { continue; }
        $name = $entry->getFilename();
        $path = ($relative !== '' ? $relative . '/' : '') . $name;
        if (in_array($path, ['storage','.git','.tools','docs/screenshots','tests/artifacts','app/config.local.php','.env','.env.local'], true)) { continue; }
        $target = $to . DIRECTORY_SEPARATOR . $name;
        if ($entry->isDir()) { copyFixture($entry->getPathname(), $target, $path); }
        elseif (!copy($entry->getPathname(), $target)) { throw new RuntimeException('Could not copy a fixture file.'); }
    }
}
function removeFixture(string $directory): void
{
    foreach (new DirectoryIterator($directory) as $entry) {
        if ($entry->isDot()) { continue; }
        if ($entry->isDir() && !$entry->isLink()) { removeFixture($entry->getPathname()); }
        else { unlink($entry->getPathname()); }
    }
    rmdir($directory);
}
function apacheCheck(string $message, bool $ok): void
{
    global $passed;
    if (!$ok) { throw new RuntimeException('FAIL ' . $message); }
    ++$passed; echo 'PASS ' . $message . PHP_EOL;
}
function apacheRequest(string $method, string $path, array $fields = []): array
{
    global $base, $cookies;
    $headers = ['Connection: close'];
    if ($cookies) { $headers[] = 'Cookie: ' . implode('; ', array_map(static fn($key,$value) => $key . '=' . $value, array_keys($cookies), $cookies)); }
    if ($method === 'POST') { $headers[] = 'Content-Type: application/x-www-form-urlencoded'; }
    $context = stream_context_create(['http' => ['method'=>$method,'header'=>implode("\r\n",$headers),'content'=>$method==='POST'?http_build_query($fields):'','follow_location'=>0,'ignore_errors'=>true,'timeout'=>15]]);
    $body = @file_get_contents('http://localhost' . $base . $path, false, $context);
    $response = $http_response_header ?? [];
    $status = (int) (explode(' ', $response[0] ?? 'HTTP/1.1 0')[1] ?? 0); $location = '';
    foreach ($response as $header) {
        if (stripos($header, 'Location: ') === 0) { $location = substr($header, 10); }
        if (stripos($header, 'Set-Cookie: ') === 0) { [$key,$value] = explode('=', explode(';', substr($header,12),2)[0],2); $cookies[$key] = $value; }
    }
    return ['status'=>$status,'location'=>$location,'body'=>$body===false?'':$body,'headers'=>$response];
}
function apacheHidden(string $html, string $name): string
{
    preg_match('/name="' . preg_quote($name,'/') . '"\s+value="([^"]*)"/', $html, $match);
    return html_entity_decode($match[1] ?? '', ENT_QUOTES, 'UTF-8');
}
function apachePost(string $path, array $fields, string $tokenPage): array
{
    $page = apacheRequest('GET',$tokenPage);
    return apacheRequest('POST',$path,['csrf_token'=>apacheHidden($page['body'],'csrf_token')]+$fields);
}

try {
    if (file_exists($fixtureRoot)) { throw new RuntimeException('Refusing to reuse an existing fixture directory.'); }
    copyFixture($sourceRoot, $fixtureRoot);
    mkdir($fixtureRoot . '/storage',0700,true);
    copy($sourceRoot . '/storage/.htaccess', $fixtureRoot . '/storage/.htaccess');
    apacheCheck('Fresh copy has no private configuration', !is_file($fixtureRoot . '/app/config.local.php'));
    $response = apacheRequest('GET','/');
    apacheCheck('Fresh folder entry redirects to mounted setup', $response['status']===303 && $response['location']===$base.'/setup');
    apacheCheck('Session cookie is scoped to the copied folder', str_contains(strtolower(implode("\n",$response['headers'])), 'path='.strtolower($base).'/'));
    $page = apacheRequest('GET','/setup');
    apacheCheck('Browser setup form renders', $page['status']===200 && str_contains($page['body'],'MySQL administrator'));
    apacheCheck('Setup action retains the folder prefix', str_contains($page['body'],'action="'.$base.'/setup"'));
    apacheCheck('Setup rejects missing CSRF', apacheRequest('POST','/setup')['status']===403);
    $secret = 'never-retain-this-admin-value';
    $response = apachePost('/setup',['host'=>'external.example','port'=>$port,'name'=>$database,'admin_user'=>$adminUser,'admin_password'=>$secret],'/setup');
    apacheCheck('Setup rejects a remote database host', $response['status']===422);
    apacheCheck('Administrator password is never reflected', !str_contains($response['body'],$secret));
    $response = apachePost('/setup',['host'=>'127.0.0.1','port'=>$port,'name'=>$database,'admin_user'=>$adminUser,'admin_password'=>$adminPassword],'/setup');
    apacheCheck('Fresh browser setup completes without CLI configuration', $response['status']===303 && $response['location']===$base.'/register');
    apacheCheck('Private application settings were created', is_file($fixtureRoot.'/app/config.local.php'));
    $private = require $fixtureRoot.'/app/config.local.php'; $settings = $private['database'];
    apacheCheck('Only a random scoped application identity is saved', $settings['name']===$database && preg_match('/^brainloop_[a-f0-9]{12}$/D',$settings['user'])===1 && strlen($settings['password'])===48);
    $pdo = new PDO('mysql:host=127.0.0.1;port='.(int)$port.';dbname='.$database.';charset=utf8mb4',$settings['user'],$settings['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    apacheCheck('All six database tables were created', (int)$pdo->query('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE()')->fetchColumn()===6);
    apacheCheck('Installer is closed after setup', apacheRequest('GET','/setup')['status']===404);
    apacheCheck('Explicit index.php loads the homepage', apacheRequest('GET','/index.php')['status']===200);
    foreach (['/app/config.local.php','/storage/install.lock','/database/schema.mysql.sql','/scripts/setup-xampp.php','/public/index.php','/.gitignore'] as $path) {
        apacheCheck('Private path is blocked: '.$path, in_array(apacheRequest('GET',$path)['status'],[403,404],true));
    }
    apacheCheck('Mounted stylesheet loads', apacheRequest('GET','/assets/css/styles.css')['status']===200);
    $password=bin2hex(random_bytes(16)); $email='copy-check-'.bin2hex(random_bytes(4)).'@example.test';
    $response=apachePost('/register',['full_name'=>'Copy Check','email'=>$email,'password'=>$password,'password_confirmation'=>$password],'/register');
    apacheCheck('Registration stays within the copied folder', $response['location']===$base.'/dashboard');
    $page=apacheRequest('GET','/dashboard'); apacheCheck('Mounted dashboard loads', $page['status']===200 && str_contains($page['body'],'Copy'));
    $response=apachePost('/decks/create',['title'=>'Copy test deck','description'=>'Fresh folder test','subject'=>'Computer Science','color'=>'#6C5CE7'],'/dashboard');
    apacheCheck('Deck creation retains the mount', preg_match('~^'.preg_quote($base,'~').'/decks/([1-9][0-9]*)$~D',$response['location'],$match)===1); $deckId=(int)$match[1];
    $answer='Answer from the copied XAMPP folder';
    $response=apachePost('/decks/'.$deckId.'/cards/create',['question'=>'Does this copied folder work?','answer'=>$answer,'explanation'=>'All routes retain the installation folder.'],'/decks/'.$deckId);
    apacheCheck('Card creation retains the mount', $response['location']===$base.'/decks/'.$deckId);
    $response=apachePost('/study/start',['deck_id'=>(string)$deckId,'mode'=>'due'],'/decks/'.$deckId);
    apacheCheck('Study starts at its mounted route', $response['location']===$base.'/study/session');
    $page=apacheRequest('GET','/study/session'); $nonce=apacheHidden($page['body'],'nonce');
    apacheCheck('Study answer is absent before reveal', !str_contains($page['body'],$answer) && $nonce!=='');
    apachePost('/study/reveal',['nonce'=>$nonce],'/study/session'); $page=apacheRequest('GET','/study/session');
    apacheCheck('Answer reveal works through Apache', str_contains($page['body'],$answer));
    $response=apachePost('/study/rate',['nonce'=>$nonce,'rating'=>'good'],'/study/session');
    apacheCheck('Rating completes at mounted results', $response['location']===$base.'/study/results');
    apacheCheck('Review is persisted in MySQL', (int)$pdo->query('SELECT COUNT(*) FROM review_history')->fetchColumn()===1);
    apacheCheck('Analytics loads after a review', apacheRequest('GET','/analytics')['status']===200);
    apacheCheck('Logout stays within the mount', apachePost('/logout',[],'/dashboard')['location']===$base.'/login');
    echo "\n{$passed} real Apache fresh-copy checks passed.\n";
} catch (Throwable $error) {
    fwrite(STDERR, $error->getMessage().PHP_EOL); $exitCode=1;
} finally {
    $pdo=null;
    if (is_file($fixtureRoot.'/app/config.local.php')) { $private=require $fixtureRoot.'/app/config.local.php'; }
    if (($private['database']['name']??null)===$database && preg_match('/^brainloop_[a-f0-9]{12}$/D',$private['database']['user']??'')) {
        $admin->exec('DROP USER IF EXISTS '.$admin->quote($private['database']['user'])."@'127.0.0.1'");
    }
    $admin->exec('DROP DATABASE IF EXISTS `'.$database.'`');
    $resolved=realpath($fixtureRoot);
    // Verify the exact owned absolute target before recursively deleting this disposable copy.
    if ($resolved && realpath(dirname($resolved))===$htdocs && basename($resolved)===$fixtureName && preg_match('/^BrainLoop-setup-check-[a-f0-9]{12}$/D',basename($resolved))) { removeFixture($resolved); }
}
exit($exitCode);
