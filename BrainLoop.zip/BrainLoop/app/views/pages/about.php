<section class="page-hero container about-hero">
  <span class="eyebrow">ABOUT BRAINLOOP</span>
  <h1>A focused way to<br><span class="purple-text">keep learning.</span></h1>
  <p>BrainLoop is a digital flashcard learning application designed to make active recall and spaced repetition simple, organized, and effective.</p>
</section>

<section class="section container section-first about-mission">
  <div class="mission-mark" aria-hidden="true"><?= brand_mark(115) ?><span>Learn smarter.<br>Remember longer.</span></div>
  <div>
    <span class="eyebrow">OUR MISSION</span>
    <h2>Structure for your<br>next study session.</h2>
    <p class="lead">To make studying more structured, engaging, and consistent through accessible learning tools.</p>
    <p class="muted">Create flashcards around the topics that matter to you, test your recall, and return to each card on a schedule informed by your ratings. BrainLoop helps students and independent learners keep revision organized and purposeful.</p>
  </div>
</section>

<section class="section features-section">
  <div class="container">
    <div class="section-intro centered"><span class="eyebrow">HOW WE APPROACH LEARNING</span><h2>Four principles.<br>One consistent practice.</h2></div>
    <div class="grid-4">
      <?php foreach ([
        ['lightbulb','Active Recall','Try to retrieve an answer from memory before you reveal the card.'],
        ['loop','Spaced Repetition','Revisit information on a schedule based on how well you recall it.'],
        ['decks','Organized Learning','Keep related questions together in clearly named subject decks.'],
        ['analytics','Progress Awareness','Use recorded reviews and study days to understand your habits.'],
      ] as $principle): ?>
        <article class="principle-card"><?= icon($principle[0],25) ?><h3><?= e($principle[1]) ?></h3><p><?= e($principle[2]) ?></p></article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section container team-section" id="team">
  <div class="section-intro centered"><span class="eyebrow">THE PROJECT TEAM</span><h2>The people behind BrainLoop.</h2><p>BrainLoop is an independent student software engineering project built by a team of four.</p></div>
  <figure class="team-photo">
    <img src="<?= e(asset_url('/assets/images/team-photo.jpg')) ?>" alt="The four members of the BrainLoop project team together." width="3984" height="2656" loading="lazy" decoding="async">
    <figcaption>The BrainLoop project team.</figcaption>
  </figure>
  <div class="team-grid">
    <?php $members = [
      ['SHRESTHA UTTAM','Team Leader','20244110','Team leadership, backend integration, GitHub, and documentation'],
      ['THAPA MANISHA','Team Member','20244114','CSS and visual design'],
      ['B K SURAJ','Team Member','20244108','Frontend development'],
      ['KHAND THAKURI SHRADDHA','Team Member','20244122','Testing'],
    ]; ?>
    <?php foreach ($members as $member): ?>
      <article class="team-card"><p class="team-role"><?= e($member[1]) ?></p><h3><?= e($member[0]) ?></h3><span class="student-id">Student ID: <?= e($member[2]) ?></span><p class="team-contribution"><?= e($member[3]) ?></p></article>
    <?php endforeach; ?>
  </div>
</section>

<section class="section container tech-section">
  <div><span class="eyebrow">THE TECHNOLOGY</span><h2>Built on web fundamentals.</h2><p>Semantic HTML, responsive CSS, server-rendered PHP, and MySQL keep the application self-contained. Accounts, forms, study sessions, and analytics work without JavaScript.</p></div>
  <div class="tech-grid">
    <?php foreach ([['HTML5','Accessible page structure'],['CSS3','Responsive visual design'],['PHP','Server-side application'],['MySQL / MariaDB','Persistent application data']] as $tech): ?>
      <div><strong><?= e($tech[0]) ?></strong><span><?= e($tech[1]) ?></span></div>
    <?php endforeach; ?>
  </div>
</section>

<section class="vision-section container"><span class="eyebrow">OUR VISION</span><h2>A dependable place<br>for regular revision.</h2><p>Our aim is a simple, organized platform that helps students maintain consistent revision habits: clear material, focused practice, and an understandable next step.</p></section>