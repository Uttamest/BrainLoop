<?php $periodReviews = (int) array_sum(array_column($daily, 'count')); $ratingTotal = (int) array_sum($ratings); ?>
<header class="page-heading"><div><p class="eyebrow">YOUR PROGRESS</p><h1>Study analytics</h1><p>Review your study activity, recall ratings, and progress by deck.</p></div><a class="btn btn-primary" href="<?= e(url('/study')) ?>"><?= icon('study',18) ?> Open study</a></header>
<section class="stats-grid" aria-label="Learning statistics">
  <?php foreach ([['reviews','Total reviews','cards'],['today_cards','Cards reviewed today','calendar'],['current_streak','Current streak · days','flame'],['longest_streak','Longest streak · days','target']] as [$key,$label,$symbol]): ?>
    <article class="stat-card"><span class="stat-icon"><?= icon($symbol,22) ?></span><div><span class="stat-label"><?= e($label) ?></span><strong class="stat-value"><?= (int) $stats[$key] ?></strong></div></article>
  <?php endforeach; ?>
</section>
<div class="analytics-summary"><span><?= (int) $stats['decks'] ?> decks</span><span><?= (int) $stats['cards'] ?> flashcards</span><span><?= (int) $stats['due'] ?> due now</span><span>Calendar days in UTC</span></div>
<?php if (!(int) $stats['reviews']): ?><section class="panel analytics-empty"><span class="empty-icon"><?= icon('analytics',30) ?></span><div><h2>No study activity yet</h2><p>Your statistics will update after your first completed review or practice rating.</p></div><a class="btn btn-secondary" href="<?= e(url((int) $stats['cards'] > 0 ? '/study' : ($decks ? '/decks/'.(int)$decks[0]['id'].'/cards/create' : '/decks/create'))) ?>"><?= (int) $stats['cards'] > 0 ? 'Start studying' : ($decks ? 'Add your first flashcard' : 'Create your first deck') ?></a></section><?php endif; ?>
<div class="grid-2 analytics-grid">
  <section class="panel">
    <div class="panel-heading"><div><p class="eyebrow">REVIEW HISTORY</p><h2>Daily activity</h2></div><span class="badge">Last <?= count($daily) ?> days</span></div>
    <?php if ($periodReviews === 0): ?><div class="chart-empty-state"><span class="chart-empty-icon"><?= icon('calendar',28) ?></span><h3>No reviews in this period</h3><p>Review and practice ratings will appear on the day they are completed.</p></div>
    <?php else: ?>
      <div class="chart-bars analytics-chart" aria-label="Daily reviews">
        <?php $maxDaily = max(1,...array_column($daily,'count')); foreach ($daily as $day): $height = $day['count'] > 0 ? max(1,round($day['count']/$maxDaily*100)) : 0; ?>
          <div class="chart-column"><span class="chart-value"><?= (int) $day['count'] ?></span><div class="chart-bar-track"><span class="chart-bar<?= $height === 0 ? ' is-zero' : '' ?>" style="height: <?= $height ?>%"></span></div><span class="chart-label"><?= e($day['label']) ?></span><span class="sr-only"><?= e($day['date']) ?>: <?= (int) $day['count'] ?> reviews</span></div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <p class="page-footnote">Includes scheduled reviews and intentional practice. Dates use UTC.</p>
  </section>
  <section class="panel">
    <div class="panel-heading"><div><p class="eyebrow">YOUR RECALL RATINGS</p><h2>Rating distribution</h2></div><?= icon('target') ?></div>
    <?php if ($ratingTotal === 0): ?><div class="chart-empty-state"><span class="chart-empty-icon"><?= icon('target',28) ?></span><h3>No ratings recorded</h3><p>Rate your recall after revealing an answer to begin your rating history.</p></div>
    <?php else: ?>
      <div class="rating-bars">
        <?php foreach (['again'=>'Again','hard'=>'Hard','good'=>'Good','easy'=>'Easy'] as $rating=>$label): $ratingCount = (int) ($ratings[$rating] ?? 0); $percent = (int) round($ratingCount/$ratingTotal*100); ?>
          <div class="rating-row rating-<?= e($rating) ?>"><div><span><?= e($label) ?></span><strong><?= $ratingCount ?> <span class="muted">· <?= $percent ?>%</span></strong></div><div class="progress-track" role="progressbar" aria-label="<?= e($label) ?> ratings" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?= $percent ?>"><span class="progress-fill" style="width: <?= $percent ?>%"></span></div></div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <p class="page-footnote">Ratings reflect your own assessment of how well you recalled each answer.</p>
  </section>
</div>
<section class="panel">
  <div class="panel-heading"><div><p class="eyebrow">BY SUBJECT</p><h2>Deck progress</h2></div><a class="text-link" href="<?= e(url('/decks')) ?>">View decks</a></div>
  <?php if (!$decks): ?><p class="empty-copy">Create a deck to start tracking progress across your subjects.</p>
  <?php else: ?>
    <div class="table-scroll"><table class="data-table"><caption class="sr-only">Your decks and learning progress</caption><thead><tr><th scope="col">Deck</th><th scope="col">Cards</th><th scope="col">Due now</th><th scope="col">Mastery</th></tr></thead><tbody>
    <?php foreach ($decks as $deck): ?><tr><th scope="row"><a href="<?= e(url('/decks/' . ((int) $deck['id']))) ?>"><?= e($deck['title']) ?></a><span class="table-subtext"><?= e($deck['subject'] ?: 'General') ?></span></th><td><?= (int) $deck['card_count'] ?></td><td><?= (int) $deck['due_count'] ?></td><td><div class="table-progress"><div class="progress-track"><span class="progress-fill" style="width: <?= (int) $deck['progress'] ?>%"></span></div><span><?= (int) $deck['progress'] ?>%</span></div></td></tr><?php endforeach; ?>
    </tbody></table></div>
  <?php endif; ?>
  <p class="page-footnote">Mastery means a card has reached a review interval of at least 21 days. Streaks count distinct UTC dates with recorded reviews; a study day today or yesterday can continue your current streak.</p>
</section>
<section class="panel"><div class="panel-heading"><h2>Recent learning activity</h2></div>
  <?php if (!$activity): ?><p class="empty-copy">Completed review and practice ratings will appear here.</p>
  <?php else: ?><ol class="activity-list"><?php foreach ($activity as $item): ?><li class="activity-item"><span class="activity-icon"><?= icon('check',17) ?></span><div><strong><?= e(excerpt($item['question'],100)) ?></strong><p><?= e($item['deck_title']) ?> · <?= e(ucfirst($item['rating'])) ?><?= !empty($item['is_practice']) ? ' · Practice' : '' ?></p></div><time datetime="<?= e($item['reviewed_at']) ?>"><?= e(format_date($item['reviewed_at'],'M j · H:i')) ?> UTC</time></li><?php endforeach; ?></ol><?php endif; ?>
</section>