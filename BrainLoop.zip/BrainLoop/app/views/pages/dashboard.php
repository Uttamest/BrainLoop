<?php
$daily = array_slice($daily, -7);
$firstName = explode(' ', trim($user['full_name']))[0];
$hour = (int) gmdate('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');
$due = (int) $stats['due'];
$reviewedLater = (int) $stats['today_scheduled'];
$reviewWorkload = $reviewedLater + $due;
$reviewPercent = $reviewWorkload > 0 ? (int) round($reviewedLater / $reviewWorkload * 100) : 0;
$weekReviews = (int) array_sum(array_column($daily, 'count'));
$hasCards = (int) $stats['cards'] > 0;
$hasDecks = !empty($decks);
$nextStep = $hasCards ? '/study' : ($hasDecks ? '/decks/' . (int) $decks[0]['id'] . '/cards/create' : '/decks/create');
?>
<header class="page-heading">
  <div><p class="eyebrow">OVERVIEW</p><h1><?= e($greeting) ?>, <?= e($firstName) ?>.</h1><p>Your decks, scheduled reviews, and recent study activity in one place.</p></div>
  <a class="btn btn-primary" href="<?= e(url('/decks/create')) ?>"><?= icon('plus') ?> Create a deck</a>
</header>
<section class="stats-grid" aria-label="Learning overview">
  <?php foreach ([['decks','Total decks','decks','Subject collections'],['cards','Total flashcards','cards','Across all decks'],['due','Due for review','clock','Ready to review now'],['current_streak','Current streak','flame','Consecutive study days']] as [$key,$label,$symbol,$footnote]): ?>
    <article class="stat-card"><span class="stat-icon"><?= icon($symbol,22) ?></span><div><span class="stat-label"><?= e($label) ?></span><strong class="stat-value"><?= (int) $stats[$key] ?></strong></div><span class="stat-footnote"><?= e($footnote) ?></span></article>
  <?php endforeach; ?>
</section>
<div class="dashboard-grid">
  <div class="dashboard-main">
    <section class="review-banner">
      <div>
        <span class="badge badge-purple"><?= $due > 0 ? 'TODAY’S REVIEWS' : ($hasCards ? 'SCHEDULE UP TO DATE' : ($hasDecks ? 'ADD STUDY MATERIAL' : 'GET STARTED')) ?></span>
        <h2><?= $due > 0 ? $due . ($due === 1 ? ' card is ready for review.' : ' cards are ready for review.') : ($hasCards ? 'You’re up to date.' : ($hasDecks ? 'Add your first flashcards.' : 'Build your first study deck.')) ?></h2>
        <p><?= $due > 0 ? 'Review your due cards and rate your recall to schedule the next session.' : ($hasCards ? 'No cards are due right now. You can practice your material or add new flashcards.' : ($hasDecks ? 'Your decks are ready. Add a question and answer to begin your first review.' : 'Create a deck, add a few focused questions, and begin your first review.')) ?></p>
        <?php if ($reviewWorkload > 0): ?>
          <div class="today-review-snapshot">
            <div class="progress-caption"><strong>Today’s review queue</strong><span><?= $reviewPercent ?>%</span></div>
            <div class="progress-track" role="progressbar" aria-label="Today’s review queue" aria-valuenow="<?= $reviewPercent ?>" aria-valuemin="0" aria-valuemax="100"><span class="progress-fill" style="width: <?= $reviewPercent ?>%"></span></div>
            <p class="field-hint"><?= $reviewedLater ?> reviewed today and scheduled later · <?= $due ?> due now</p>
            <p class="field-hint">The queue updates as cards become due.</p>
          </div>
        <?php endif; ?>
        <a class="btn btn-primary" href="<?= e(url($nextStep)) ?>"><?= icon($hasCards ? 'study' : ($hasDecks ? 'cards' : 'plus')) ?> <?= $due > 0 ? 'Start review' : ($hasCards ? 'Open study' : ($hasDecks ? 'Add your first flashcard' : 'Create your first deck')) ?></a>
      </div>
    </section>
    <nav class="quick-actions" aria-label="Quick actions">
      <a class="quick-action" href="<?= e(url('/decks/create')) ?>"><?= icon('plus',20) ?><span><strong>Create a deck</strong><small>Organize a new subject</small></span></a>
      <a class="quick-action" href="<?= e(url($decks ? '/decks/'.(int)$decks[0]['id'].'/cards/create' : '/decks/create')) ?>"><?= icon('cards',20) ?><span><strong>Add a flashcard</strong><small><?= $decks ? 'Add to your latest deck' : 'Create a deck first' ?></small></span></a>
      <a class="quick-action" href="<?= e(url('/study')) ?>"><?= icon('study',20) ?><span><strong>Start studying</strong><small>Review or practice</small></span></a>
      <a class="quick-action" href="<?= e(url('/analytics')) ?>"><?= icon('analytics',20) ?><span><strong>View analytics</strong><small>Understand your activity</small></span></a>
    </nav>
    <section class="panel">
      <div class="panel-heading"><div><p class="eyebrow">YOUR COLLECTION</p><h2>Recent decks</h2></div><a class="text-link" href="<?= e(url('/decks')) ?>">View all decks</a></div>
      <?php if (!$decks): ?>
        <div class="empty-state"><span class="empty-icon"><?= icon('decks',32) ?></span><h3>No decks yet</h3><p>A deck keeps related flashcards together. Create your first deck to start building your study material.</p><a href="<?= e(url('/decks/create')) ?>" class="btn btn-primary"><?= icon('plus') ?> Create your first deck</a></div>
      <?php else: ?>
        <div class="deck-grid compact-decks">
          <?php foreach (array_slice($decks,0,4) as $deck): ?>
            <article class="deck-card" style="--deck-color: <?= e($deck['color']) ?>">
              <div class="deck-card-top"><span class="deck-color"><?= icon('decks',22) ?></span><span class="badge"><?= e($deck['subject'] ?: 'General') ?></span></div>
              <h3><a href="<?= e(url('/decks/' . ((int) $deck['id']))) ?>"><?= e($deck['title']) ?></a></h3>
              <p><?= e(excerpt($deck['description'] ?: 'No description added.',90)) ?></p>
              <div class="deck-meta"><span><?= (int) $deck['card_count'] ?> cards</span><span><?= (int) $deck['due_count'] ?> due</span></div>
              <div class="progress-track" role="progressbar" aria-label="<?= e($deck['title']) ?> mastery" aria-valuenow="<?= (int) $deck['progress'] ?>" aria-valuemin="0" aria-valuemax="100"><span class="progress-fill" style="width: <?= (int) $deck['progress'] ?>%"></span></div>
              <div class="deck-footer"><span><?= (int) $deck['progress'] ?>% mastered</span><a class="text-link" href="<?= e(url('/decks/' . ((int) $deck['id']))) ?>">Open deck</a></div>
            </article>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
  </div>
  <aside class="dashboard-aside">
    <section class="panel">
      <div class="panel-heading"><div><p class="eyebrow">LAST SEVEN DAYS</p><h2>Study activity</h2></div><?= icon('analytics') ?></div>
      <?php if ($weekReviews === 0): ?>
        <div class="chart-empty-state"><span class="chart-empty-icon"><?= icon('analytics',28) ?></span><h3>No reviews in this period</h3><p>Complete a review or practice session to record your activity here.</p></div>
      <?php else: ?>
        <p class="muted"><?= (int) $weekReviews ?> reviews and practice ratings</p>
        <div class="chart-bars" aria-label="Daily review counts">
          <?php $maxDaily = max(1,...array_column($daily,'count')); foreach ($daily as $day): $height = $day['count'] > 0 ? max(1,round($day['count']/$maxDaily*100)) : 0; ?>
            <div class="chart-column"><span class="chart-value"><?= (int) $day['count'] ?></span><div class="chart-bar-track"><span class="chart-bar<?= $height === 0 ? ' is-zero' : '' ?>" style="height: <?= $height ?>%"></span></div><span class="chart-label"><?= e($day['label']) ?></span><span class="sr-only"><?= e($day['date']) ?>: <?= (int) $day['count'] ?> reviews</span></div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <a class="text-link" href="<?= e(url('/analytics')) ?>">View study analytics</a>
    </section>
    <section class="panel">
      <div class="panel-heading"><h2>Recent activity</h2><span class="badge"><?= (int) $stats['reviews'] ?> total</span></div>
      <?php if (!$activity): ?><p class="empty-copy">No reviews recorded yet. Completed review and practice ratings will appear here.</p>
      <?php else: ?><ol class="activity-list"><?php foreach (array_slice($activity,0,4) as $item): ?><li class="activity-item"><span class="activity-icon"><?= icon('check',17) ?></span><div><strong><?= e($item['deck_title']) ?></strong><p><?= e(ucfirst($item['rating'])) ?><?= !empty($item['is_practice']) ? ' · Practice' : ' · Review' ?></p><time datetime="<?= e($item['reviewed_at']) ?>"><?= e(format_date($item['reviewed_at'],'M j · H:i')) ?> UTC</time></div></li><?php endforeach; ?></ol><?php endif; ?>
    </section>
    <section class="tip-card"><span class="eyebrow"><?= icon('lightbulb',16) ?> STUDY TIP</span><h3>Recall before you reveal.</h3><p>Read the question and try to answer it from memory. Reveal the answer when you’re ready, then rate your recall honestly.</p></section>
  </aside>
</div>
