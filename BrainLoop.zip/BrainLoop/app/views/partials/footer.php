<footer class="site-footer">
  <div class="container footer-main">
    <div><a class="brand" href="<?= e(url('/')) ?>" aria-label="BrainLoop home"><?= brand_mark() ?><span>BrainLoop</span></a><p class="muted">Learn smarter. Remember longer.</p></div>
    <div class="footer-links">
      <div><strong>Explore</strong><a href="<?= e(url('/features')) ?>">Features</a><a href="<?= e(url('/how-it-works')) ?>">How it works</a><a href="<?= e(url('/about')) ?>">About BrainLoop</a></div>
      <div><strong>Your learning</strong><a href="<?= e(url('/register')) ?>">Create an account</a><a href="<?= e(url('/login')) ?>">Log in</a><a href="<?= e(url('/privacy')) ?>">Privacy policy</a><a href="<?= e(url('/terms')) ?>">Terms of use</a></div>
    </div>
  </div>
  <div class="container footer-bottom"><span>&copy; <?= date('Y') ?> BrainLoop.</span><span>A focused space for your next study session.</span></div>
</footer>