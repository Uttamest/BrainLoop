<?php
declare(strict_types=1);
namespace App\Core;

use PDO;
use RuntimeException;

final class Database
{
    private static ?PDO $pdo = null;

    public static function driver(): string
    {
        if ((config()['database']['driver'] ?? 'mysql') !== 'mysql') { throw new RuntimeException('BrainLoop requires the MySQL database driver. Update your private database configuration.'); }
        return 'mysql';
    }

    public static function mysqlConnection(bool $withDatabase = true, ?array $settings = null): PDO
    {
        if (!extension_loaded('pdo_mysql')) { throw new RuntimeException('Enable pdo_mysql in your PHP configuration. See README.'); }
        $settings ??= config()['database'];
        if (!is_string($settings['host'] ?? null) || strlen($settings['host']) > 253 || !preg_match('/^[A-Za-z0-9_.:-]+$/D', $settings['host'])) { throw new RuntimeException('Use a valid database hostname without connection-string delimiters.'); }
        $port = $settings['port'] ?? null;
        if ((!is_int($port) && !is_string($port)) || !preg_match('/^[1-9][0-9]{0,4}$/D', (string) $port) || (int) $port > 65535) { throw new RuntimeException('Use a database port from 1 to 65535.'); }
        if (!is_string($settings['user'] ?? null) || $settings['user'] === '' || str_contains($settings['user'], "\0") || !is_string($settings['password'] ?? null) || str_contains($settings['password'], "\0")) { throw new RuntimeException('Use valid private database credentials.'); }
        if (!is_string($settings['name'] ?? null)) { throw new RuntimeException('Use a valid database name.'); }
        $name = self::databaseName((string) $settings['name']);
        $dsn = 'mysql:host=' . $settings['host'] . ';port=' . (int) $settings['port'] . ($withDatabase ? ';dbname=' . $name : '') . ';charset=utf8mb4';
        $pdo = new PDO($dsn, (string) $settings['user'], (string) $settings['password'], self::options());
        $pdo->exec("SET time_zone = '+00:00'");
        $pdo->exec("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION,ONLY_FULL_GROUP_BY'");
        return $pdo;
    }

    public static function databaseName(string $name): string
    {
        if (!preg_match('/^[A-Za-z0-9_]{1,64}$/D', $name)) { throw new RuntimeException('Use only letters, numbers, and underscores in the database name (maximum 64 characters).'); }
        return $name;
    }

    private static function options(): array
    {
        return [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false, PDO::MYSQL_ATTR_MULTI_STATEMENTS => false];
    }

    public static function connection(): PDO
    {
        if (self::$pdo !== null) { return self::$pdo; }
        self::driver();
        return self::$pdo = self::mysqlConnection();
    }

    public static function migrate(?PDO $connection = null): void
    {
        $pdo = $connection ?? self::connection();
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) !== 'mysql') { throw new RuntimeException('BrainLoop schema initialization requires a MySQL connection.'); }
        $file = dirname(__DIR__, 2) . '/database/schema.mysql.sql';
        $schema = file_get_contents($file);
        if ($schema === false) { throw new RuntimeException('The database schema file is missing.'); }
        // The checked-in schema contains CREATE statements without stored routines.
        foreach (explode(';', $schema) as $statement) {
            if (trim($statement) !== '') { $pdo->exec($statement); }
        }
    }
}
