param([string]$XamppPath = 'C:\xampp')
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$httpd = Join-Path $XamppPath 'apache\bin\httpd.exe'
$vhosts = Join-Path $XamppPath 'apache\conf\extra\httpd-vhosts.conf'
$template = Join-Path $PSScriptRoot 'xampp-vhost.conf'
if (-not (Test-Path -LiteralPath $httpd) -or -not (Test-Path -LiteralPath $vhosts)) { throw 'XAMPP Apache was not found. Supply -XamppPath with your installation folder.' }
& $httpd -t 2>&1 | ForEach-Object { "$PSItem" }
if ($LASTEXITCODE -ne 0) { throw 'Existing Apache configuration is invalid. It was not changed.' }
$existing = [IO.File]::ReadAllText($vhosts)
$marker = '# BEGIN BrainLoop local host'
if ($existing.Contains($marker)) {
    Write-Output 'BrainLoop Apache configuration is already installed.'
    exit
}
$publicRoot = (Join-Path $projectRoot 'public').Replace('\','/')
$defaultRoot = (Join-Path $XamppPath 'htdocs').Replace('\','/')
$definition = [IO.File]::ReadAllText($template).Replace('C:/Users/acer/OneDrive/Desktop/BrainLoop/public', $publicRoot)
$block = "`r`n$marker`r`n"
# When XAMPP has no active named hosts, retain its original localhost document root.
if (-not [regex]::IsMatch($existing, '(?im)^\s*<VirtualHost\s')) {
    $block += "<VirtualHost *:80>`r`n    ServerName localhost`r`n    DocumentRoot `"$defaultRoot`"`r`n</VirtualHost>`r`n`r`n"
}
$block += $definition + "`r`n# END BrainLoop local host`r`n"
$backup = $vhosts + '.brainloop-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmssfff')
Copy-Item -LiteralPath $vhosts -Destination $backup
[IO.File]::WriteAllText($vhosts, $existing + $block, [Text.UTF8Encoding]::new($false))
try {
    & $httpd -t 2>&1 | ForEach-Object { "$PSItem" }
    if ($LASTEXITCODE -ne 0) { throw 'Apache rejected the new configuration.' }
} catch {
    Copy-Item -LiteralPath $backup -Destination $vhosts -Force
    throw "Apache configuration was restored from backup: $($_.Exception.Message)"
}
Write-Output 'BrainLoop is configured at http://brainloop.localhost . Start or restart Apache in XAMPP.'
Write-Output "Original Apache configuration backup: $backup"
