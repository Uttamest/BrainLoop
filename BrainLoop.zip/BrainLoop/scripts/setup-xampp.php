<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
define('BRAINLOOP_CLI', true);
require dirname(__DIR__) . '/app/bootstrap.php';

try {
    if (PHP_VERSION_ID < 80200) { throw new RuntimeException('BrainLoop requires PHP 8.2 or newer.'); }
    $localFile = dirname(__DIR__) . '/app/config.local.php';
    if (is_file($localFile)) {
        if (App\Core\Database::driver() !== 'mysql') { throw new RuntimeException('Existing local settings select a different database driver. Update them explicitly first.'); }
        App\Core\Database::migrate();
        echo "Existing private MySQL configuration verified. No credentials changed.\n";
        exit;
    }
    $settings = config()['database'];
    if (!in_array($settings['host'], ['127.0.0.1', 'localhost'], true)) { throw new RuntimeException('This helper provisions only a local XAMPP database. Use setup.php for other servers.'); }
    $name = App\Core\Database::databaseName($settings['name']);
    $adminSettings = $settings;
    $adminSettings['user'] = getenv('BRAINLOOP_ADMIN_DB_USER') !== false ? getenv('BRAINLOOP_ADMIN_DB_USER') : 'root';
    $adminSettings['password'] = getenv('BRAINLOOP_ADMIN_DB_PASSWORD') !== false ? getenv('BRAINLOOP_ADMIN_DB_PASSWORD') : '';
    $admin = App\Core\Database::mysqlConnection(false, $adminSettings);
    $admin->exec('CREATE DATABASE IF NOT EXISTS `' . $name . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $admin->exec('USE `' . $name . '`');
    App\Core\Database::migrate($admin);
    $username = 'brainloop_' . bin2hex(random_bytes(4));
    $password = bin2hex(random_bytes(24));
    $account = $admin->quote($username) . '@' . $admin->quote($settings['host']);
    $admin->exec('CREATE USER ' . $account . ' IDENTIFIED BY ' . $admin->quote($password));
    // No global privileges or access to unrelated databases.
    $grantName = str_replace('_', '\\_', $name);
    $admin->exec('GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX ON `' . $grantName . '`.* TO ' . $account);
    $appSettings = array_replace($settings, ['driver' => 'mysql', 'user' => $username, 'password' => $password]);
    App\Core\Database::mysqlConnection(true, $appSettings)->query('SELECT COUNT(*) FROM users')->fetchColumn();
    $contents = "<?php\ndeclare(strict_types=1);\n\n// Private local credentials. Excluded from Git.\nreturn " . var_export(['env' => 'development', 'https' => false, 'database' => $appSettings], true) . ";\n";
    $handle = fopen($localFile, 'x');
    if (!$handle) { throw new RuntimeException('Could not create private configuration. Existing files are never overwritten.'); }
    try { if (fwrite($handle, $contents) !== strlen($contents)) { throw new RuntimeException('Could not save complete private configuration.'); } }
    finally { fclose($handle); }
    @chmod($localFile, 0600);
    echo "BrainLoop MySQL database and tables are ready.\n";
    echo "A dedicated local database account was created. Credentials are in ignored app/config.local.php and were not printed.\n";
    echo "No default learning account or sample reviews were created.\n";
    echo "Start Apache with the supplied virtual host, or run: php -S localhost:8000 -t public public/router.php\n";
} catch (Throwable $error) {
    fwrite(STDERR, 'XAMPP setup failed: ' . $error->getMessage() . "\nStart MySQL in XAMPP. If root has a password, set BRAINLOOP_ADMIN_DB_PASSWORD for this command.\n");
    exit(1);
}
