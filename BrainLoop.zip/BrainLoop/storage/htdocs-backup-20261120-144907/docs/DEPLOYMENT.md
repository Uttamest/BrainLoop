# Deploying BrainLoop

BrainLoop requires a PHP-capable server. GitHub is source hosting; GitHub Pages cannot run the PHP application. This repository does not configure a public host or claim a live deployment.

## Runtime and files

Use PHP 8.2+ with PDO and `pdo_mysql`; deploy a current supported security release. The default backend is MySQL/MariaDB with InnoDB and utf8mb4. Use MySQL 8.0.16+ or MariaDB 10.4+ so database CHECK constraints are enforced. SQLite remains an explicit alternative requiring `pdo_sqlite`. No Composer, Node.js, asset build, external API, or JavaScript runtime is needed.

Point the website document root at the repository's **`public/` directory**, never its parent. Keep application code, database, private configuration, scripts, tests, and Git metadata outside the public root. Do not deploy a directory listing of the repository as your site.

Environment variables:

```text
BRAINLOOP_ENV=production
BRAINLOOP_DB_DRIVER=mysql
BRAINLOOP_DB_HOST=127.0.0.1
BRAINLOOP_DB_PORT=3306
BRAINLOOP_DB_NAME=brainloop
BRAINLOOP_DB_USER=brainloop
BRAINLOOP_DB_PASSWORD=YOUR_PRIVATE_DATABASE_PASSWORD
BRAINLOOP_HTTPS=1
```

Use the actual host and private credential. `.env.example` documents the names; the project does not parse `.env` files. Supply values through your web server, PHP-FPM pool, hosting control panel, or process manager. Alternatively, an ignored `app/config.local.php` can return private overrides; real environment variables take precedence. Keep credentials out of Git and application output.

Create a dedicated database and database account scoped to it. Run `php scripts/setup.php` with the same database environment as the web process. Migration is idempotent and does not clear user data. If a trusted setup identity can create databases, `php scripts/setup.php --create-database` can create the configured database first. Never grant the normal application global database-administrator privileges. Allow the schema initialization operations required by the supplied setup/front controller within its own database. Do not make unrelated source files writable by the web process.

## XAMPP on this Windows machine

Keep the source at `C:\Users\acer\OneDrive\Desktop\BrainLoop`. Start XAMPP MySQL. This service may be MariaDB even though the Control Panel labels it MySQL. In PowerShell:

```powershell
cd "C:\Users\acer\OneDrive\Desktop\BrainLoop"
$env:Path = "C:\xampp\php;" + $env:Path
php scripts/setup-xampp.php
php scripts/setup.php
powershell -ExecutionPolicy Bypass -File .\scripts\setup-apache.ps1
```

`setup-xampp.php` connects using the local XAMPP administrator credentials, creates the `brainloop` database and a dedicated generated database user, and saves the random application password in the ignored `app/config.local.php`. It does not print the password or overwrite an existing local configuration. Supply `BRAINLOOP_ADMIN_DB_USER` / `BRAINLOOP_ADMIN_DB_PASSWORD` privately if the local administrator credentials differ from XAMPP's default `root`/empty password. This provisioning helper is for local setup; use your host's secure database provisioning procedure in production.

Start XAMPP Apache and open [http://brainloop.localhost](http://brainloop.localhost). MySQL must remain running. Stop Apache/MySQL through the XAMPP Control Panel when they are no longer needed.

The PowerShell setup script defaults to `C:\xampp` (override with `-XamppPath`), backs up `httpd-vhosts.conf`, preserves the existing localhost/default site, adds an idempotent BrainLoop virtual-host block, validates the result, and restores its backup if Apache validation fails. Restart Apache after configuration changes. The supplied `scripts/xampp-vhost.conf` is also available as a manual reference. Its `DocumentRoot` and matching `<Directory>` must point directly to `C:/Users/acer/OneDrive/Desktop/BrainLoop/public`, with local-only access. The app must be hosted at the virtual-host root; browsing the repository folder through `/BrainLoop/` is unsupported. Do not expose the entire OneDrive/Desktop tree as a web document root.

For an alternative development server while keeping the same MySQL backend:

```powershell
php -S localhost:8000 -t public public/router.php
```

Open [http://localhost:8000](http://localhost:8000) and stop that development process with Ctrl+C. It is not a production service.

## Apache

Enable PHP and `mod_rewrite`, set `DocumentRoot` to `/absolute/path/BrainLoop/public`, and allow the supplied `.htaccess` rewrite rules (typically `AllowOverride FileInfo Options`). Permit `Require all granted` for the public directory only. Disable directory indexes. If your host forbids `.htaccess`, copy its rules into the virtual-host configuration.

The app assumes it is served at the hostname root, such as `https://study.example.org/`, rather than a subdirectory. Its navigation uses absolute paths beginning with `/`.

## Nginx with PHP-FPM

Use the correct PHP-FPM socket or upstream for the host. A representative location policy is:

```nginx
root /srv/BrainLoop/public;
index index.php;

location / {
    try_files $uri $uri/ /index.php?$query_string;
}

location = /index.php {
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME $document_root/index.php;
    fastcgi_pass unix:/run/php/php-fpm.sock;
}

location ~ \.php$ { return 404; }
location ~ /\. { deny all; }
```

Adjust paths and the socket to the installation. Deny PHP execution for uploaded content if future features add uploads; BrainLoop's CSV import does not retain uploaded files in the public tree.

## HTTPS and errors

Serve login and all authenticated pages over HTTPS. Direct HTTPS is detected from the web server. Behind trusted TLS termination, set `BRAINLOOP_HTTPS=1` in trusted server configuration so sessions use Secure cookies. Do not set it during ordinary HTTP localhost development. Session cookies are HttpOnly and SameSite=Lax, and authenticated sessions regenerate their IDs.

Disable public PHP error display, enable error logging to a private destination, and restrict log access. BrainLoop's web bootstrap disables displayed errors. Monitor your host's error log and available disk space. Keep session files outside the public tree and configure appropriate expiration/cleanup on the host.

The built-in PHP server is a development convenience and must not be exposed as a production service.

## Backups and database portability

The database contains account data, password hashes, private study material, and review history. Back it up with access controls and a retention policy suitable to that data. Test restores to a separate database before relying on a backup. MySQL/MariaDB data is managed by its server, not stored in this source directory.

Use the database server's consistent dump/backup tooling and a scoped backup identity. For InnoDB, a properly configured transactional dump avoids partial snapshots of active writes. Protect both dumps and restore credentials. Do not copy a running MySQL/MariaDB data directory as a substitute for a tested backup procedure. Do not commit SQL dumps or database files to Git, put them in `public/`, or share unprotected download links.

Changing `BRAINLOOP_DB_DRIVER` does not migrate data automatically. Existing SQLite files are preserved and can be opened with explicit driver/path configuration; there is no automatic cross-engine data transfer. A future migration should be deliberate, backed up, and validated for ownership/history consistency.

For optional SQLite hosting, set `BRAINLOOP_DB_DRIVER=sqlite` and a private `BRAINLOOP_DB_PATH`. Give PHP access to that directory, including WAL/SHM sidecars. Use SQLite's online backup facility or stop writes before a consistent copy that accounts for WAL state. SQLite serializes writes and is suited to a small single-server deployment on durable local storage; avoid ephemeral disks and unreliable network filesystems.

## Before releasing

Run the automated suite and syntax checks, create a real account, exercise the functional checklist in `docs/TESTING.md`, verify ownership isolation with two accounts, and confirm no source/storage files can be fetched over HTTP. Ensure sample decks are deliberate and no fixed-password accounts exist. Check current runtime security patches and verify the backup/restore process for the actual host.
