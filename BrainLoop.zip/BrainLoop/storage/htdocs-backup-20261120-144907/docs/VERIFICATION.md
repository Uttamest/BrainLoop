# Local verification record

## MySQL/MariaDB conversion — 2026-11-19

Verified locally with **PHP 8.2.12**, **MariaDB 10.4.32 from XAMPP**, and PDO MySQL. MySQL/MariaDB is now the default application backend; SQLite is an explicit alternative. No public production deployment or hosted GitHub Actions run is claimed.

| Check | Observed result |
| --- | --- |
| XAMPP database provisioning | Database and tables initialized; dedicated scoped user/password saved in ignored private configuration without printing credentials |
| PHP syntax | 48 local PHP files passed `php -l` (including the ignored local configuration) |
| MySQL/MariaDB model/database suite | 73 passed, 0 failed |
| MySQL/MariaDB HTTP suite | 87 passed, 0 failed |
| Optional SQLite model/database suite | 73 passed, 0 failed |
| Optional SQLite HTTP suite | 87 passed, 0 failed |
| Rendered routes/assets | Each HTTP mode inspected 24 public/private pages and 34 local targets; favicon delivered; no rendered scripts/event handlers |
| Apache virtual host | Configuration validation passed; `http://brainloop.localhost` returned 200 |
| Existing localhost site | Original `http://localhost` remained available with HTTP 200 |
| Private configuration over Apache | `/app/config.local.php` returned 404 |
| Browser flow on actual XAMPP Apache | Logged in, revealed and rated a card, and viewed completion; MySQL stored the Good rating and a one-day next interval |
| Normal MySQL data after verification | Only the temporary verification account was removed; the normal database is empty and ready for registration |
| Existing SQLite data | Original SQLite file retained; no automatic cross-engine copying performed |

The model and HTTP suites use randomly named temporary schemas and scoped test users for MariaDB; they do not use the application's normal database. The test schemas/users were dropped after completion. SQLite tests use memory/temporary files and leave the original SQLite data untouched.

The actual Apache browser check used a separately identified temporary account, which was removed after confirming the persisted review. Its screenshot is saved locally as `docs/screenshots/mysql-xampp-result.jpg`. Apache and MySQL were started for verification and stopped afterward; start both using the XAMPP Control Panel to use `http://brainloop.localhost`.

Run both database modes using the isolated harness:

```powershell
php tests/run.php
php tests/http.php
php tests/run.php --mysql
php tests/http.php --mysql
```

The default commands explicitly choose isolated SQLite. `--mysql` creates a fresh randomly named test database and random scoped user using separate administrator test credentials, then drops only the database/user it created. Normal application accounts and data are excluded from fixtures. The MySQL-specific local runs used XAMPP's MariaDB implementation; Oracle MySQL and production HTTPS hosting were not exercised. The CI matrix is configured for PHP 8.2/8.3/8.4 with a MariaDB service but has not been run on GitHub during this work.

## Original SQLite/browser verification — 2026-11-18

Verified on **2026-11-18** in the requested Windows project directory with **PHP 8.2.12**, PDO SQLite, and the ChatGPT in-app browser.

| Check | Observed result |
| --- | --- |
| Database initialization | `php scripts/setup.php` succeeded; setup is idempotent |
| PHP syntax | All 44 PHP files passed `php -l` |
| Scheduler, model, database, security helpers | 73 tests passed, 0 failed |
| HTTP functional and security suite | 87 checks passed, 0 failed |
| Internal links and assets | 24 rendered pages inspected; 34 local targets passed |
| Frontend restrictions | No JavaScript/TypeScript source files; rendered-page tests found no scripts or event handlers |
| Responsive layouts | 21 page states exercised at 375, 768, 1024, and 1440 pixels; identified overflow was corrected and affected states rechecked |
| Authentication layouts | Login and registration checked at all four widths without horizontal page overflow |
| Long content | A 117-character unbroken title, long subject, 2,000-character question, and 5,000-character answer exercised; final deck view fit all four widths |
| Keyboard study flow | Revealed and rated three sample cards using Enter; progress advanced and the completion screen displayed the actual saved rating distribution |
| Normal application data | Normal database retained empty, with no default account or sample reviews |

The HTTP suite covers registration, duplicate email rejection, session regeneration, login failures and throttling, logout, protected routes, deck/card CRUD and ownership, answer withholding, reveal, ratings, stale and duplicate submissions, due filtering, practice preserving schedules, partial session exit, analytics, search escaping, account updates, password changes, CSV import validation and formula-safe export, sample seeding, and cascading deletion.

Screenshots under `docs/screenshots/` show the real local interface and optional, explicitly labeled sample decks. Dashboard and analytics screenshots reflect three reviews actually performed during browser verification. The temporary preview database and its test account were removed, and the development preview server was stopped. Screenshots are ignored by Git by default; review and intentionally add selected images if using them in a public portfolio.

## Scope limits

- Verification used the installed PHP 8.2.12 runtime. The configured GitHub Actions PHP 8.2/8.3/8.4 matrix has not been executed on GitHub during this task.
- Apache/Nginx production hosting, HTTPS termination, and public deployment were documented but not exercised locally.
- Keyboard operation, selected text contrast, semantic labels, responsive behavior, and reduced-motion CSS were checked; this is not a formal WCAG conformance certification or independent security audit.
- The original development preview server was stopped. Follow the current README commands for XAMPP MySQL/MariaDB setup and local hosting.

Run verification again with:

```powershell
php tests/run.php
php tests/http.php
```
