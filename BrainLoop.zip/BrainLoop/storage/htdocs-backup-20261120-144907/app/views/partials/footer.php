<footer class="site-footer">
  <div class="container footer-main">
    <div><a class="brand" href="/" aria-label="BrainLoop home"><?= brand_mark() ?><span>BrainLoop</span></a><p class="muted">Learn smarter.<br>Remember longer.</p></div>
    <div class="footer-links"><div><strong>Explore</strong><a href="/features">Features</a><a href="/how-it-works">How it works</a><a href="/about">About BrainLoop</a></div><div><strong>Get started</strong><a href="/register">Create an account</a><a href="/login">Log in</a><a href="/privacy">Privacy policy</a><a href="/terms">Terms of use</a></div></div>
  </div>
  <div class="container footer-bottom"><span>&copy; <?= date('Y') ?> BrainLoop. An independent student project.</span><span>Made with care, for the way you learn.</span></div>
  <div class="container team-credit"><a href="/about#team">The BrainLoop team</a>: SHRESTHA UTTAM (20244110) · THAPA MANISHA (20244114) · B K SURAJ (20244108) · KHAND THAKURI SHRADDHA (20244122)</div>
</footer>
