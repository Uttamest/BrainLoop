<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
define('BRAINLOOP_CLI', true);
require __DIR__ . '/DatabaseSandbox.php';
$sandbox = new DatabaseSandbox($argv, true);
$sandbox->apply();
require dirname(__DIR__) . '/app/bootstrap.php';
$sandbox->assertConfiguration(config());

$passed = 0;
$failed = 0;
function check(string $name, callable $assertion): void
{
    global $passed, $failed;
    try {
        if ($assertion() === false) {
            throw new RuntimeException('Assertion returned false.');
        }
        ++$passed;
        echo "PASS {$name}\n";
    } catch (Throwable $error) {
        ++$failed;
        echo "FAIL {$name}: {$error->getMessage()}\n";
    }
}
function same(mixed $actual, mixed $expected): bool
{
    if ($actual !== $expected) {
        throw new RuntimeException('Expected ' . var_export($expected, true) . ', got ' . var_export($actual, true));
    }
    return true;
}

$scheduler = new App\Services\Scheduler();
$now = new DateTimeImmutable('2026-11-18 12:00:00', new DateTimeZone('UTC'));
$again = $scheduler->schedule([], 'again', $now);
$hard = $scheduler->schedule([], 'hard', $now);
$good = $scheduler->schedule([], 'good', $now);
$easy = $scheduler->schedule([], 'easy', $now);
check('Again has an exact ten-minute relearning step', fn () => same($again['due_at'], '2026-11-18 12:10:00'));
check('Again resets repetitions and labels relearning', fn () => $again['repetition_count'] === 0 && $again['review_state'] === 'relearning');
check('Again reduces ease by 0.2', fn () => same($again['ease_factor'], 2.3));
check('First Hard interval is one day', fn () => $hard['interval_days'] === 1 && $hard['due_at'] === '2026-11-19 12:00:00');
check('First Good interval is one day', fn () => same($good['interval_days'], 1));
check('First Easy interval is four days', fn () => $easy['interval_days'] === 4 && $easy['due_at'] === '2026-11-22 12:00:00');
check('Successful recall increments counters and labels review', fn () => $good['repetition_count'] === 1 && $good['total_reviews'] === 1 && $good['review_state'] === 'review');
check('Hard reduces ease by 0.15', fn () => same($hard['ease_factor'], 2.35));
check('Easy raises ease by 0.15', fn () => same($easy['ease_factor'], 2.65));
$good2 = $scheduler->schedule($good, 'good', $now);
$good3 = $scheduler->schedule($good2, 'good', $now);
check('Second Good interval is six days', fn () => same($good2['interval_days'], 6));
check('Third Good interval follows prior ease factor', fn () => same($good3['interval_days'], 15));
check('Second Hard interval is three days', fn () => same($scheduler->schedule($hard, 'hard', $now)['interval_days'], 3));
check('Second Easy interval is eight days', fn () => same($scheduler->schedule($easy, 'easy', $now)['interval_days'], 8));
check('Second Hard after Easy still grows the previous interval', fn () => same($scheduler->schedule($easy, 'hard', $now)['interval_days'], 5));
check('Later Hard uses ceil(previous * 1.2)', fn () => same($scheduler->schedule(['repetition_count' => 3, 'interval_days' => 10], 'hard', $now)['interval_days'], 12));
check('Later Easy uses prior ease * 1.3 before ease adjustment', fn () => same($scheduler->schedule(['repetition_count' => 3, 'interval_days' => 10, 'ease_factor' => 2.5], 'easy', $now)['interval_days'], 33));
check('Failed recall resets a mature card', fn () => $scheduler->schedule($good3, 'again', $now)['repetition_count'] === 0);
check('Good following a lapse restarts at one day', fn () => same($scheduler->schedule($again, 'good', $now)['interval_days'], 1));
check('Ease cannot fall below 1.3', fn () => same($scheduler->schedule(['ease_factor' => 1.3], 'again', $now)['ease_factor'], 1.3));
check('Ease cannot exceed 3.0', fn () => same($scheduler->schedule(['ease_factor' => 3.0], 'easy', $now)['ease_factor'], 3.0));
check('Successful intervals are capped at 36500 days', fn () => same($scheduler->schedule(['repetition_count' => 100, 'interval_days' => 36500], 'easy', $now)['interval_days'], 36500));
check('Review timestamp is recorded in UTC', fn () => same($scheduler->schedule([], 'good', new DateTimeImmutable('2026-11-18 21:00:00+09:00'))['last_reviewed_at'], '2026-11-18 12:00:00'));
check('A leap-day review advances correctly', fn () => same($scheduler->schedule([], 'good', new DateTimeImmutable('2028-02-28 00:00:00Z'))['due_at'], '2028-02-29 00:00:00'));
check('The scheduler is deterministic', fn () => same($scheduler->schedule($good3, 'good', $now), $scheduler->schedule($good3, 'good', $now)));
check('Invalid ratings are rejected', function () use ($scheduler, $now) { try { $scheduler->schedule([], 'perfect', $now); } catch (InvalidArgumentException) { return true; } return false; });
check('Successful intervals are always positive', function () use ($scheduler, $now) { foreach (['hard', 'good', 'easy'] as $rating) { if ($scheduler->schedule(['interval_days' => -99], $rating, $now)['interval_days'] < 1) { return false; } } return true; });
check('HTML output escaping handles markup and quotes', fn () => same(e('<script>"&</script>'), '&lt;script&gt;&quot;&amp;&lt;/script&gt;'));
check('Multiline UTF-8 text validation preserves content', fn () => valid_text("Cell\n세포", 1, 100));
check('NUL and invalid UTF-8 are rejected', fn () => !valid_text("a\0b", 1, 100) && !valid_text("\xFF", 1, 100));
check('Invalid resource IDs are rejected', fn () => valid_id('1 OR 1=1') === 0 && valid_id('-1') === 0 && valid_id('1') === 1);
check('LIKE metacharacters are escaped', fn () => same(like_term('a%_!'), '%a!%!_!!%'));
check('Password hashes verify without plaintext storage', function () { $password = 'test-password-with-entropy'; $hash = password_hash($password, PASSWORD_DEFAULT); return $hash !== $password && password_verify($password, $hash) && !password_verify('wrong', $hash); });

check('Schema initializes and migration is idempotent', function () use ($sandbox) { App\Core\Database::migrate(); App\Core\Database::migrate(); $query = $sandbox->driver === 'mysql' ? "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name IN ('users','decks','flashcards','card_progress','review_history')" : "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('users','decks','flashcards','card_progress','review_history')"; return (int) db()->query($query)->fetchColumn() === 5; });
$pdo = db();
check('Foreign key enforcement is enabled', fn () => same((int) $pdo->query($sandbox->driver === 'mysql' ? 'SELECT @@FOREIGN_KEY_CHECKS' : 'PRAGMA foreign_keys')->fetchColumn(), 1));
$stamp = '2026-11-18 12:00:00';
$insertUser = $pdo->prepare('INSERT INTO users(full_name,email,password_hash,created_at,updated_at) VALUES(?,?,?,?,?)');
$insertUser->execute(['Test Student', 'test@example.invalid', password_hash('test-password-with-entropy', PASSWORD_DEFAULT), $stamp, $stamp]);
$userId = (int) $pdo->lastInsertId();
check('Email uniqueness is case-insensitive', function () use ($insertUser, $stamp) { try { $insertUser->execute(['Other', 'TEST@example.invalid', 'hash', $stamp, $stamp]); } catch (PDOException) { return true; } return false; });
$pdo->prepare('INSERT INTO decks(user_id,title,created_at,updated_at) VALUES(?,?,?,?)')->execute([$userId, 'Test deck', $stamp, $stamp]);
$deckId = (int) $pdo->lastInsertId();
$pdo->prepare('INSERT INTO flashcards(deck_id,question,answer,created_at,updated_at) VALUES(?,?,?,?,?)')->execute([$deckId, "What is 2 + 2?\nThink first.", '4', $stamp, $stamp]);
$cardId = (int) $pdo->lastInsertId();
$pdo->prepare('INSERT INTO card_progress(user_id,flashcard_id,due_at) VALUES(?,?,?)')->execute([$userId, $cardId, $stamp]);
check('New cards default to immediately eligible with no reviews', function () use ($pdo, $stamp) { $row = $pdo->query('SELECT * FROM card_progress')->fetch(); return $row['review_state'] === 'new' && $row['due_at'] === $stamp && (int) $row['total_reviews'] === 0; });
check('Prepared statements treat SQL injection strings as data', function () use ($pdo) { $statement = $pdo->prepare('SELECT COUNT(*) FROM users WHERE email = ?'); $statement->execute(["' OR 1=1 --"]); return (int) $statement->fetchColumn() === 0; });
check('Progress is unique per card', function () use ($pdo, $userId, $cardId, $stamp) { try { $pdo->prepare('INSERT INTO card_progress(user_id,flashcard_id,due_at) VALUES(?,?,?)')->execute([$userId, $cardId, $stamp]); } catch (PDOException) { return true; } return false; });
check('Future-due cards are excluded by the due predicate', function () use ($pdo, $stamp) { $pdo->exec("UPDATE card_progress SET due_at='2026-11-19 12:00:00'"); $find = $pdo->prepare('SELECT COUNT(*) FROM card_progress WHERE due_at <= ?'); $find->execute([$stamp]); return (int) $find->fetchColumn() === 0; });
$reviewInsert = $pdo->prepare('INSERT INTO review_history(user_id,flashcard_id,rating,interval_before,interval_after,reviewed_at,is_practice,submission_key) VALUES(?,?,?,?,?,?,?,?)');
$reviewInsert->execute([$userId, $cardId, 'good', 0, 1, $stamp, 0, 'unique-test-submission']);
check('Duplicate rating submission keys are rejected', function () use ($reviewInsert, $userId, $cardId, $stamp) { try { $reviewInsert->execute([$userId, $cardId, 'good', 0, 1, $stamp, 0, 'unique-test-submission']); } catch (PDOException) { return true; } return false; });
check('Invalid rating history cannot be stored', function () use ($reviewInsert, $userId, $cardId, $stamp) { try { $reviewInsert->execute([$userId, $cardId, 'invalid', 0, 1, $stamp, 0, 'invalid-test-submission']); } catch (PDOException) { return true; } return false; });
check('Transactions roll back partial changes', function () use ($pdo, $deckId) { $pdo->beginTransaction(); $pdo->prepare('UPDATE decks SET title=? WHERE id=?')->execute(['Should roll back', $deckId]); $pdo->rollBack(); return $pdo->query('SELECT title FROM decks')->fetchColumn() === 'Test deck'; });
check('Deleting a deck cascades through cards, schedules, and history', function () use ($pdo, $deckId) { $pdo->prepare('DELETE FROM decks WHERE id=?')->execute([$deckId]); foreach (['flashcards', 'card_progress', 'review_history'] as $table) { if ((int) $pdo->query('SELECT COUNT(*) FROM ' . $table)->fetchColumn() !== 0) { return false; } } return true; });
check('Foreign keys reject orphan cards', function () use ($pdo, $stamp) { try { $pdo->prepare('INSERT INTO flashcards(deck_id,question,answer,created_at,updated_at) VALUES(?,?,?,?,?)')->execute([999999, 'Q', 'A', $stamp, $stamp]); } catch (PDOException) { return true; } return false; });

$repository = store();
$otherUser = $repository->createUser('Other Student', 'other@example.invalid', 'another-test-password');
$ownedDeck = $repository->createDeck($userId, ['title' => 'Biology 100%', 'description' => 'Test collection', 'subject' => 'Science', 'color' => '#6C5CE7']);
$ownedCard = $repository->createCard($ownedDeck, $userId, ['question' => "Basic unit of life?\nRecall before revealing.", 'answer' => 'Cell', 'explanation' => 'Test explanation']);
check('Deck and flashcard creation produce an immediate due schedule', fn () => $repository->deck($ownedDeck, $userId)['card_count'] === 1 && $repository->card($ownedCard, $userId)['review_state'] === 'new' && in_array($ownedCard, $repository->studyCards($userId, $ownedDeck, 'due'), true));
check('Other users cannot read decks or cards', fn () => $repository->deck($ownedDeck, $otherUser) === null && $repository->card($ownedCard, $otherUser) === null && $repository->cards($ownedDeck, $otherUser) === []);
check('Other users cannot create cards in a private deck', function () use ($repository, $ownedDeck, $otherUser) { try { $repository->createCard($ownedDeck, $otherUser, ['question' => 'Q', 'answer' => 'A', 'explanation' => '']); } catch (DomainException) { return true; } return false; });
check('Other users cannot edit private decks', function () use ($repository, $ownedDeck, $otherUser, $userId) { $repository->updateDeck($ownedDeck, $otherUser, ['title' => 'Unauthorized', 'description' => '', 'subject' => '', 'color' => '#6C5CE7']); return $repository->deck($ownedDeck, $userId)['title'] === 'Biology 100%'; });
check('Other users cannot edit or delete private cards', function () use ($repository, $ownedCard, $otherUser, $userId) { $repository->updateCard($ownedCard, $otherUser, ['question' => 'Unauthorized', 'answer' => 'A', 'explanation' => '']); $repository->deleteCard($ownedCard, $otherUser); return str_starts_with($repository->card($ownedCard, $userId)['question'], 'Basic unit'); });
check('Private data is excluded from other users search', fn () => $repository->decks($otherUser, 'Biology') === [] && $repository->searchCards($otherUser, 'Cell') === []);
check('Deck search treats a percent character literally', fn () => count($repository->decks($userId, '100%')) === 1 && count($repository->decks($userId, '100_')) === 0);
check('Card search covers both questions and answers', fn () => count($repository->searchCards($userId, 'Basic unit')) === 1 && count($repository->searchCards($userId, 'Cell')) === 1);
check('Review saves history and updates the real due date', function () use ($repository, $ownedCard, $userId) { $saved = $repository->review($userId, $ownedCard, 'good', false, 'store-review-1'); $card = $repository->card($ownedCard, $userId); return $saved && (int) $card['total_reviews'] === 1 && $card['last_rating'] === 'good' && $card['due_at'] > utc_now(); });
check('Today review snapshot counts a card scheduled into the future', fn () => $repository->stats($userId)['today_scheduled'] === 1 && $repository->stats($userId)['due'] === 0);
check('Review retries are idempotent', fn () => $repository->review($userId, $ownedCard, 'good', false, 'store-review-1') === false && (int) $repository->card($ownedCard, $userId)['total_reviews'] === 1);
check('Due-only sessions omit future cards but practice includes them', fn () => $repository->studyCards($userId, $ownedDeck, 'due') === [] && $repository->studyCards($userId, $ownedDeck, 'practice') === [$ownedCard]);
check('Future-due cards cannot be rated through a due review', function () use ($repository, $ownedCard, $userId) { try { $repository->review($userId, $ownedCard, 'easy', false, 'store-future-review'); } catch (DomainException) { return true; } return false; });
check('Practice records history without changing scheduling', function () use ($repository, $ownedCard, $userId) { $before = $repository->card($ownedCard, $userId); $saved = $repository->review($userId, $ownedCard, 'easy', true, 'store-practice-1'); return $saved && $repository->card($ownedCard, $userId) === $before; });
check('Practice does not inflate scheduled-review snapshot progress', fn () => $repository->stats($userId)['today_scheduled'] === 1);
check('Other users cannot submit private card ratings', function () use ($repository, $ownedCard, $otherUser) { try { $repository->review($otherUser, $ownedCard, 'good', true, 'store-unauthorized-review'); } catch (DomainException) { return true; } return false; });
check('Statistics include real practice history and unique reviewed cards', function () use ($repository, $userId) { $stats = $repository->stats($userId); return $stats['decks'] === 1 && $stats['cards'] === 1 && $stats['due'] === 0 && $stats['reviews'] === 2 && $stats['today_cards'] === 1 && $stats['current_streak'] === 1; });
check('Rating distribution and activity match persisted history', function () use ($repository, $userId) { $ratings = $repository->ratings($userId); $activity = $repository->activity($userId); return $ratings['good'] === 1 && $ratings['easy'] === 1 && count($activity) === 2; });
check('Activity chart has fourteen real UTC day buckets', fn () => count($repository->daily($userId)) === 14 && array_sum(array_column($repository->daily($userId), 'count')) === 2);
$history = $pdo->prepare('INSERT INTO review_history(user_id,flashcard_id,rating,interval_before,interval_after,reviewed_at,is_practice,submission_key) VALUES(?,?,?,?,?,?,?,?)');
foreach ([1, 2, 5, 6, 7, 8] as $ago) {
    $day = (new DateTimeImmutable('today', new DateTimeZone('UTC')))->modify('-' . $ago . ' days')->format('Y-m-d H:i:s');
    $history->execute([$userId, $ownedCard, 'good', 1, 1, $day, 1, 'streak-day-' . $ago]);
}
check('Streak counts distinct consecutive UTC dates, not review volume', function () use ($repository, $userId) { $stats = $repository->stats($userId); return $stats['current_streak'] === 3 && $stats['longest_streak'] === 4; });
check('Bulk import rolls back all rows when a row fails', function () use ($repository, $ownedDeck, $userId) { $before = count($repository->cards($ownedDeck, $userId)); try { $repository->importCards($ownedDeck, $userId, [['question' => 'Valid first', 'answer' => 'A', 'explanation' => ''], ['question' => null, 'answer' => 'A', 'explanation' => '']]); } catch (Throwable) { return count($repository->cards($ownedDeck, $userId)) === $before; } return false; });
check('Owner can edit a card without resetting its schedule', function () use ($repository, $ownedCard, $userId) { $due = $repository->card($ownedCard, $userId)['due_at']; $repository->updateCard($ownedCard, $userId, ['question' => 'Updated question', 'answer' => 'Updated answer', 'explanation' => '']); $after = $repository->card($ownedCard, $userId); return $after['question'] === 'Updated question' && $after['due_at'] === $due; });
check('Editing a card refreshes its parent deck timestamp', function () use ($repository, $ownedCard, $ownedDeck, $userId, $pdo) { $pdo->prepare('UPDATE decks SET updated_at=? WHERE id=?')->execute(['2000-01-01 00:00:00', $ownedDeck]); $repository->updateCard($ownedCard, $userId, ['question' => 'Timestamp test', 'answer' => 'A', 'explanation' => '']); return $repository->deck($ownedDeck, $userId)['updated_at'] > '2000-01-01 00:00:00'; });
check('Login failures enforce the documented ten-attempt threshold', function () use ($repository) { for ($i = 0; $i < 10; ++$i) { $repository->loginFailure('throttle@example.invalid', '192.0.2.1'); } return $repository->throttled('throttle@example.invalid', '192.0.2.2') && $repository->throttled('another@example.invalid', '192.0.2.1'); });
check('Owner can update profile and password', function () use ($repository, $userId) { $repository->updateProfile($userId, 'Updated Student', 'updated@example.invalid'); $repository->updatePassword($userId, 'replacement-test-password'); $user = $repository->user($userId); return $user['full_name'] === 'Updated Student' && $user['email'] === 'updated@example.invalid' && password_verify('replacement-test-password', $user['password_hash']); });
check('Other users cannot delete a private deck', function () use ($repository, $ownedDeck, $otherUser, $userId) { $repository->deleteDeck($ownedDeck, $otherUser); return $repository->deck($ownedDeck, $userId) !== null; });
check('Owner can delete a card and its history', function () use ($repository, $ownedCard, $ownedDeck, $userId, $pdo) { $pdo->prepare('UPDATE decks SET updated_at=? WHERE id=?')->execute(['2000-01-01 00:00:00', $ownedDeck]); $repository->deleteCard($ownedCard, $userId); return $repository->card($ownedCard, $userId) === null && (int) $pdo->query('SELECT COUNT(*) FROM review_history')->fetchColumn() === 0; });
check('Deleting a card refreshes its parent deck timestamp', fn () => $repository->deck($ownedDeck, $userId)['updated_at'] > '2000-01-01 00:00:00');
check('Owner can delete a deck', function () use ($repository, $ownedDeck, $userId) { $repository->deleteDeck($ownedDeck, $userId); return $repository->deck($ownedDeck, $userId) === null; });

echo "\n{$passed} passed; {$failed} failed. All data used " . $sandbox->description() . ".\n";
exit($failed === 0 ? 0 : 1);
