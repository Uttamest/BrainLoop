from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
archive = root.parent / 'BrainLoop-XAMPP.zip'
if archive.exists():
    raise SystemExit('The release archive already exists; preserve it before creating another version.')
excluded = {'.git', '.tools', '__pycache__'}
files = []
for path in root.rglob('*'):
    if not path.is_file() or path.is_symlink():
        continue
    relative = path.relative_to(root)
    name = relative.as_posix()
    if any(part in excluded for part in relative.parts):
        continue
    if name == 'app/config.local.php' or (relative.name.startswith('.env') and name != '.env.example'):
        continue
    if name.startswith(('docs/screenshots/', 'tests/artifacts/')):
        continue
    if name.startswith('storage/') and name not in ('storage/.gitkeep', 'storage/.htaccess'):
        continue
    if path.suffix.lower() in ('.sqlite', '.sqlite3', '.db', '.log', '.bak', '.tmp', '.pid'):
        continue
    files.append((path, 'BrainLoop/' + name))
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as target:
    for path, name in files:
        target.write(path, name)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None
    names = target.namelist()
    assert 'BrainLoop/index.php' in names
    assert 'BrainLoop/.htaccess' in names
    assert 'BrainLoop/docs/BrainLoop_Project_Report.pdf' in names
    assert 'BrainLoop/public/assets/images/team-photo.jpg' in names
    assert 'BrainLoop/app/config.local.php' not in names
    assert not any(name.startswith('BrainLoop/storage/') and name not in ('BrainLoop/storage/.gitkeep', 'BrainLoop/storage/.htaccess') for name in names)
print(f'Created clean package: {len(files)} files; {archive.stat().st_size:,} bytes. ZIP integrity and private-file exclusions verified.')
