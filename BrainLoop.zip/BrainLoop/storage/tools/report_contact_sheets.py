from pathlib import Path
import sys
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1] / 'report-render'
prefix = sys.argv[1] if len(sys.argv) > 1 else 'page'
pages = sorted(root.glob(prefix + '-*.png'))
for start in range(0, len(pages), 6):
    sheet = Image.new('RGB', (1248, 1184), '#dddddd')
    draw = ImageDraw.Draw(sheet)
    for i, path in enumerate(pages[start:start+6]):
        page = Image.open(path).convert('RGB')
        page.thumbnail((396, 560))
        x, y = (i % 3) * 416 + 10, (i // 3) * 592
        draw.text((x, y + 5), path.stem, fill='black')
        sheet.paste(page, (x, y + 24))
    sheet.save(root / (prefix + '-sheet-' + str(start // 6 + 1) + '.jpg'))
print(str(len(pages)) + ' pages prepared for visual review.')
