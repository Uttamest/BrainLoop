<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { exit(1); }
$root = dirname(__DIR__, 2);
define('BRAINLOOP_CLI', true);
require $root . '/tests/DatabaseSandbox.php';
$sandbox = new DatabaseSandbox();
$sandbox->apply();
require $root . '/app/bootstrap.php';
App\Core\Database::migrate();
$now = utc_now();
$email = 'browser-check@example.invalid';
$password = bin2hex(random_bytes(16));
db()->prepare('INSERT INTO users(full_name,email,password_hash,created_at,updated_at) VALUES(?,?,?,?,?)')->execute(['Browser Check', $email, password_hash($password, PASSWORD_DEFAULT), $now, $now]);
$socket = stream_socket_server('tcp://127.0.0.1:0', $errorCode, $errorMessage);
if (!$socket) { throw new RuntimeException('Cannot allocate fixture port.'); }
$port = (int) substr(strrchr(stream_socket_get_name($socket, false), ':'), 1);
fclose($socket);
$log = $root . '/storage/browser-fixture.log';
$process = proc_open([PHP_BINARY, '-S', '127.0.0.1:' . $port, '-t', 'public', 'public/router.php'], [0=>['pipe','r'], 1=>['file',$log,'a'], 2=>['file',$log,'a']], $pipes, $root, array_replace(getenv(),$sandbox->environment), ['bypass_shell'=>true]);
if (!is_resource($process)) { throw new RuntimeException('Cannot start browser fixture.'); }
fclose($pipes[0]);
register_shutdown_function(static function () use ($process): void { if (is_resource($process)) { proc_terminate($process); proc_close($process); } });
echo json_encode(['url'=>'http://127.0.0.1:' . $port, 'email'=>$email, 'password'=>$password]) . PHP_EOL;
flush();
$stop = $root . '/storage/browser-fixture.stop';
while (!is_file($stop)) { usleep(250000); }
unlink($stop);
proc_terminate($process); proc_close($process);
$sandbox->cleanup();
echo "Owned browser fixture removed.\n";
