from pathlib import Path
import json, re, html, datetime, math
from reportlab.pdfgen import canvas
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, LongTable, TableStyle, PageBreak, Image, KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing, Rect, Line, Polygon, String, Circle
from reportlab.graphics import renderSVG

ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / 'docs'
ASSETS = DOCS / 'assets'
ASSETS.mkdir(exist_ok=True)
META = json.loads((DOCS / 'report-metadata.json').read_text(encoding='utf-8-sig'))
metrics_file = DOCS / 'report-metrics.json'
METRICS = json.loads(metrics_file.read_text(encoding='utf-8-sig')) if metrics_file.exists() else {}
for name, filename in [('Arial','arial.ttf'),('Arial-Bold','arialbd.ttf'),('Arial-Italic','ariali.ttf')]:
    pdfmetrics.registerFont(TTFont(name, 'C:/Windows/Fonts/' + filename))
INK = colors.HexColor('#172033')
NAVY = colors.HexColor('#253651')
PURPLE = colors.HexColor('#5144C7')
TEAL = colors.HexColor('#147D70')
GRAY = colors.HexColor('#667085')
PALE = colors.HexColor('#F2F4F8')
BORDER = colors.HexColor('#D9D9D9')
WIDTH = A4[0] - 96
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='ReportTitle',fontName='Arial-Bold',fontSize=26,leading=32,textColor=colors.black,spaceAfter=22))
styles.add(ParagraphStyle(name='ReportSubtitle',fontName='Arial',fontSize=13,leading=19,textColor=colors.black,spaceAfter=16))
styles.add(ParagraphStyle(name='Chapter',fontName='Arial-Bold',fontSize=19,leading=24,textColor=colors.black,spaceAfter=17,keepWithNext=True))
styles.add(ParagraphStyle(name='Subhead',fontName='Arial-Bold',fontSize=12.5,leading=17,textColor=colors.black,spaceBefore=14,spaceAfter=8,keepWithNext=True))
styles.add(ParagraphStyle(name='Body',fontName='Arial',fontSize=10.5,leading=15,spaceAfter=9,textColor=INK))
styles.add(ParagraphStyle(name='BulletBody',parent=styles['Body'],leftIndent=12,firstLineIndent=-9,spaceAfter=6))
styles.add(ParagraphStyle(name='SmallBody',parent=styles['Body'],fontSize=9,leading=12.5,spaceAfter=6))
styles.add(ParagraphStyle(name='Cell',fontName='Arial',fontSize=9,leading=12,textColor=INK))
styles.add(ParagraphStyle(name='CellHead',parent=styles['Cell'],fontName='Arial-Bold',textColor=colors.white))
styles.add(ParagraphStyle(name='Caption',parent=styles['Body'],fontSize=9,leading=12,textColor=GRAY,spaceBefore=8,spaceAfter=14))
styles.add(ParagraphStyle(name='CodeBlock',fontName='Courier',fontSize=8.3,leading=12,spaceAfter=11))
story=[]; md=[]; chapter_count=0

def escape(value): return html.escape(str(value)).replace('\n','<br/>')
def para(text, style='Body'):
    story.append(Paragraph(escape(text),styles[style]));md.append(text+'\n')
def sub(title):
    story.append(Paragraph(escape(title),styles['Subhead']));md.append('### '+title+'\n')
def chapter(title):
    global chapter_count
    chapter_count += 1
    story.append(PageBreak())
    p=Paragraph(str(chapter_count)+' '+escape(title),styles['Chapter'])
    p._bookmarkName='chapter-'+str(chapter_count)
    story.append(p);md.append('## '+str(chapter_count)+' '+title+'\n')
def bullets(items):
    for item in items:
        story.append(Paragraph('&#8226; '+escape(item),styles['BulletBody']))
        md.append('- '+item)
    md.append('')
def table(headers, rows, widths=None, caption=None):
    widths=[WIDTH*w for w in widths] if widths else [WIDTH/len(headers)]*len(headers)
    data=[[Paragraph(escape(h),styles['CellHead']) for h in headers]]
    data += [[Paragraph(escape(c),styles['Cell']) for c in row] for row in rows]
    t=LongTable(data,colWidths=widths,repeatRows=1,hAlign='LEFT',splitByRow=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('GRID',(0,0),(-1,-1),.45,BORDER),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE])]))
    t.spaceAfter = 12
    story.append(t)
    md.append('| '+' | '.join(headers)+' |')
    md.append('| '+' | '.join('---' for _ in headers)+' |')
    for row in rows:md.append('| '+' | '.join(str(c).replace('|','/').replace('\n','<br>') for c in row)+' |')
    md.append('')
    if caption:para(caption,'Caption')
def code(text):
    story.append(Paragraph(escape(text),styles['CodeBlock']));md.extend(['```text',text,'```',''])
def label(d,x,y,text,size=10,color=INK,font='Arial',anchor='start'):
    d.add(String(x,y,text,fontName=font,fontSize=size,fillColor=color,textAnchor=anchor))
def box(d,x,y,w,h,lines,fill=PALE,size=10):
    d.add(Rect(x,y,w,h,rx=7,fillColor=fill,strokeColor=BORDER,strokeWidth=.8))
    if isinstance(lines,str):lines=lines.split('\n')
    start=y+h/2+(len(lines)-1)*7
    for i,line in enumerate(lines):label(d,x+w/2,start-i*14,line,size,anchor='middle',font='Arial-Bold' if i==0 else 'Arial')
def arrow(d,x1,y1,x2,y2,text=None):
    d.add(Line(x1,y1,x2,y2,strokeColor=GRAY,strokeWidth=1.1))
    angle=math.atan2(y2-y1,x2-x1);length=6
    pts=[x2,y2,x2-length*math.cos(angle-.45),y2-length*math.sin(angle-.45),x2-length*math.cos(angle+.45),y2-length*math.sin(angle+.45)]
    d.add(Polygon(pts,fillColor=GRAY,strokeColor=GRAY))
    if text:label(d,(x1+x2)/2+4,(y1+y2)/2+5,text,8.5,GRAY)
def diagram(name,drawing,caption):
    renderSVG.drawToFile(drawing,str(ASSETS/(name+'.svg')))
    story.append(drawing);para(caption,'Caption')
    md.append('!['+caption+'](assets/'+name+'.svg)\n')

class Report(BaseDocTemplate):
    def afterFlowable(self,flowable):
        if isinstance(flowable,Paragraph) and hasattr(flowable,'_bookmarkName'):
            key=flowable._bookmarkName
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(flowable.getPlainText(),key,0,False)
            self.notify('TOCEntry',(0,flowable.getPlainText(),self.page,key))

def page_decoration(c,doc):
    c.saveState();c.setFillColor(GRAY);c.setFont('Arial',8)
    if doc.page>1:c.drawString(48,A4[1]-29,'BrainLoop software engineering project report')
    c.drawString(48,25,'Planned submission and presentation 8 December 2026')
    c.drawRightString(A4[0]-48,25,str(doc.page));c.restoreState()

story.append(Spacer(1,36))
para('BrainLoop Software Engineering Project Report','ReportTitle')
para('Requirements design implementation testing and delivery planning','ReportSubtitle')
para('Report date 25 November 2026\nProject schedule 15 September to 8 December 2026\nClass presentation and submission 8 December 2026','ReportSubtitle')
para('BrainLoop is a server-rendered flashcard application for active recall and scheduled review. This report explains the software engineering process, requirements, models, architecture, MySQL design, implementation, verification, team responsibilities, and planned delivery. It connects the project to the nine supplied lecture resources and provides an operational basis for the class demonstration.')
table(['Project member','Student ID','Role'],[[m['name'],m['student_id'],m['role']] for m in META['team']],[.53,.22,.25])
para('The development timeline is a planned baseline. Responsibility assignments follow the contribution areas provided by the team. Completed implementation checks are reported separately from future presentation and acceptance activities.','SmallBody')
md=['# BrainLoop Software Engineering Project Report\n','Report date: 25 November 2026. Planned delivery: 8 December 2026.\n']+md

story.append(PageBreak());story.append(Paragraph('Contents',styles['Chapter']))
toc=TableOfContents();toc.levelStyles=[ParagraphStyle(name='ContentsEntry',fontName='Arial',fontSize=10.5,leading=17,leftIndent=0,firstLineIndent=0,spaceBefore=4,textColor=INK)]
story.append(toc)

chapter('Project overview')
para('Students often keep revision material across notebooks, documents, and disconnected files. Locating the right question, deciding what to review, and noticing missed revision can take time away from learning. BrainLoop addresses this organizational problem with private decks, concise questions and answers, an explicit review queue, and a record of study activity.')
para('The application is intended for university and college students, examination preparation, language learning, and self-directed revision. It is a learning organizer and recall practice tool. It does not promise a particular examination result or a scientifically measured retention percentage.')
sub('Objectives')
bullets(['Provide an understandable account and private workspace for each learner.','Support complete deck and flashcard creation, editing, search, import, export, and deletion.','Keep the answer out of the initial study response so learners attempt recall first.','Use deterministic recall ratings to update actual MySQL due dates and preserve review history.','Display activity, due counts, streaks, and deck progress from stored records.','Run locally by copying the whole folder into XAMPP htdocs and opening its index page.'])
sub('Scope boundary')
para('The delivered scope covers a single PHP application, MySQL-compatible persistence, browser forms, and local Apache hosting. Email delivery, password-reset emails, public deck sharing, mobile applications, payment processing, and external authentication are outside this release. The interface runs without JavaScript or a frontend build system.')
para('The distinction between a system specification, its implementation, and a test result follows the introductory lecture discussion of software processes and essential quality attributes. [L01, PDF p 5; L02, PDF pp 1 to 3]')

chapter('Stakeholders feasibility and ethical considerations')
table(['Stakeholder','Need','Project response'],[
['Learner','Private, organized revision and clear next steps','Owned decks, due reviews, understandable ratings, genuine activity data.'],
['Project team','Maintainable work allocation and integration','Shared design conventions, PHP modules, task responsibilities, regression tests.'],
['Class assessor','Evidence connecting engineering decisions to working software','Requirements, design models, traceability, test record, demonstration plan.'],
['Local installation operator','Reliable setup, backup, and protected configuration','Browser installer, scoped database identity, protected folders, XAMPP instructions.']],[.19,.30,.51])
sub('Feasibility assessment')
para('Technical feasibility is supported by the installed XAMPP environment, PHP 8.2 or newer, the PDO MySQL driver, and a MySQL or MariaDB server. The website uses semantic HTML and CSS; no package installation or browser scripting is needed. A local installation can operate without an external API or an internet connection once the source and required server software are present.')
para('Operational feasibility depends on a learner being able to understand decks, questions, answer reveal, and self-ratings. Empty states and direct labels reduce the amount of instruction required. The setup guide distinguishes the database administrator used during installation from the ordinary BrainLoop learning account.')
para('The project uses existing computers and freely available software. No unsupported currency estimate, paid service requirement, or invented labor total is included. Schedule feasibility is assessed through the phased plan and acceptance criteria rather than an assumed number of developer hours.')
sub('Ethical and privacy responsibilities')
para('Accounts contain a name, email address, password hash, and study data. Access control must prevent another learner reading or changing those records. The supplied team photograph is used on About; individual people in the photograph are not algorithmically identified or assigned to names. The team remains responsible for classroom policy, attribution, accuracy of learning content, and permission to distribute any material it imports. These concerns relate to the professional responsibility discussion in the introductory lecture. [L01, PDF pp 10 to 12]')

chapter('Development process and configuration management')
sub('Selected process')
para('An iterative and incremental process suits this project because the most useful feedback comes from working learning flows. The proposed sequence delivers a thin working account-and-deck path first, then card management, scheduled study, analytics, setup, and final polish. Each increment is reviewed against its acceptance criteria before the next integration. This follows the incremental development concepts in the process lecture. [L02, PDF pp 4 to 5 and 15 to 16]')
para('The project uses Agile practices selectively: small user stories, short feedback cycles, a prioritized backlog, and regression checks after integration. This is not a claim that a formally staffed Scrum organization, historical sprint velocity, or recorded daily meetings existed. The planned review cadence is one weekly integration review with smaller task discussions as needed. [L03, PDF p 7 and pp 12 to 15]')
table(['Increment','Working outcome','Review evidence'],[
['Foundation','Routing, sessions, database connection, public pages','Setup and syntax checks; protected-route behavior.'],
['Learning content','Owned decks and cards with validated forms','CRUD, ownership, multiline text, and empty-state checks.'],
['Recall workflow','Question, reveal, rating, scheduling, and results','Fixed-clock scheduler tests and HTTP study checks.'],
['Learning feedback','Search, analytics, profile, CSV, and setup','Real-history calculations and negative/edge cases.'],
['Release preparation','Professional interface, documentation, and class demo','Responsive review, regression record, backup, rehearsal.']],[.20,.42,.38])
sub('Source control and integration workflow')
para('Uttam coordinates the integration branch and review of changes across modules. A task should start with a small issue stating the expected behavior, owner, related requirement, and acceptance check. A branch can use names such as feature/deck-forms or fix/review-ownership. Commits should describe a coherent change. Before merging, run syntax checks, the MySQL model tests, HTTP tests, and relevant interface checks.')
para('GitHub configuration files, contribution guidance, an MIT license, and CI definitions are included. An actual repository URL, push history, issue count, or contributor statistics must come from the team repository; they are not invented in this report. Configuration management and licensing are linked to the implementation lecture. [L07, PDF pp 15 to 16 and p 20]')

chapter('Requirements specification')
para('The following requirements describe observable application behavior. They are expressed separately from implementation choices so that a reviewer can test what a learner receives. Functional requirements identify services; quality requirements constrain those services. This separation follows Requirements Engineering. [L04, PDF pp 5 to 9 and 18 to 24]')
table(['ID','Functional requirement','Acceptance condition'],[
['FR01','Register and authenticate learners','Validate name/email/password; reject duplicate email; hash passwords; regenerate the session after sign-in.'],
['FR02','Protect private routes and resources','Anonymous requests reach login; every owned resource is constrained to the authenticated learner.'],
['FR03','Manage decks','Create, view, edit, filter, search, and confirm deletion of owned decks; show real card and due counts.'],
['FR04','Manage flashcards','Store nonempty multiline questions and answers, optional explanations, and edit/delete owned cards.'],
['FR05','Import flashcards','Accept valid UTF-8 CSV headers and data; enforce 1 MiB and 500-card limits; reject invalid batches without partial import.'],
['FR06','Export owned decks','Return CSV with the expected columns and neutralize formula-leading spreadsheet cells.'],
['FR07','Select due reviews','Select new or due cards with due_at no later than current UTC time; omit future cards; limit a session to 200 cards.'],
['FR08','Reveal answers deliberately','Initial study HTML contains the question but no answer or explanation; POST Show answer renders the answer.'],
['FR09','Record recall ratings','Accept Again, Hard, Good, or Easy only after reveal; save scheduling and history atomically; prevent duplicate credit.'],
['FR10','Provide intentional practice','Allow non-due cards to be practiced; record practice history while leaving scheduling fields unchanged.'],
['FR11','Calculate learning analytics','Derive totals, daily activity, rating distribution, distinct-day streaks, and deck progress from stored learner records.'],
['FR12','Search private content','Search deck title/subject and card question/answer with prepared queries and escaped LIKE metacharacters.'],
['FR13','Maintain account settings','Update profile data; require the current password for an email change and for a password change.'],
['FR14','Install locally through the browser','Fresh loopback setup creates compatible MySQL tables and a scoped app identity; private settings are not public; repeat setup is closed.'],
['FR15','Present accurate project information','About contains the supplied group photograph and exact team details; the footer contains no member names or IDs.'],
['FR16','Support a copied XAMPP folder','Both /BrainLoop/ and /BrainLoop/index.php work; links, forms, assets, redirects, and cookies retain the installation path.']],[.10,.28,.62])

chapter('Quality requirements and acceptance targets')
table(['ID','Quality area','Verification target'],[
['NFR01','Security','Prepared statements, password hashing, CSRF on POST, owner checks, safe errors, and secure session settings are verified by code review and negative tests.'],
['NFR02','Data integrity','A review update and history insert commit together or roll back together. Unique card progress and review submission constraints are enforced.'],
['NFR03','Usability','Every principal task has clear labels, helpful validation, preserved nonsecret input, feedback, and meaningful empty states.'],
['NFR04','Responsive layout','Inspect representative public and private pages at 375, 768, 1024, and 1440 CSS pixels without page-level horizontal overflow.'],
['NFR05','Accessibility','Use semantic landmarks, labeled controls, visible keyboard focus, text equivalents for charts, and reduced-motion styling. Formal WCAG certification is not claimed.'],
['NFR06','Local portability','Run with PHP 8.2+, PDO MySQL, and XAMPP Apache using a folder copy and the root index entry point.'],
['NFR07','Maintainability','Separate request controllers, database queries, pure scheduling, reusable views, and URL/security helpers.'],
['NFR08','Predictability','The same progress, rating, and fixed UTC review time produce the same next schedule. Practice cannot silently change due dates.'],
['NFR09','Privacy','Keep private configuration, database backups, scripts, test files, and reports out of public HTTP access in the htdocs layout.'],
['NFR10','Efficient operation','Use local assets, appropriate ownership/due/history indexes, and bounded study/import operations. A separate load-capacity benchmark is outside the current verification.']],[.12,.21,.67])
para('A passing functional suite is not proof of every quality target. Visual inspection checks layout, automated negative cases check selected security behavior, and operational review checks installation and backups. Requirements validation should address validity, consistency, completeness, realism, and verifiability, as discussed in the lectures. [L04, PDF pp 25 to 26; L08, PDF pp 20 to 21]')

chapter('User stories and use cases')
table(['Story','Learner goal','Primary requirements'],[
['US01','As a learner, I want to organize questions into subject decks so I can revise a topic without searching unrelated notes.','FR03, FR04, FR12'],
['US02','As a learner, I want to attempt an answer before seeing it so my session involves recall rather than immediate rereading.','FR07, FR08'],
['US03','As a learner, I want my honest rating to schedule the next review so I know which cards need attention.','FR09, FR11'],
['US04','As a learner, I want optional practice without moving my schedule so I can revise before a class or test intentionally.','FR10'],
['US05','As a learner, I want my decks to remain private and exportable so I control my learning material.','FR02, FR06, FR13'],
['US06','As a local operator, I want a guided XAMPP setup so the project works after copying the folder.','FR14, FR16']],[.12,.67,.21])
para('User stories provide small planning units; use cases explain the interaction and alternatives. They are complementary rather than interchangeable. The following descriptions apply the interaction modeling concepts in the supplied lectures. [L03, PDF p 7; L05, PDF pp 6 to 8]')
for title, pre, main, alternate, post in [
('UC01 Register an account','The application database is configured and the learner is signed out.','Open registration; enter a name, email, password, and matching confirmation; submit the CSRF-protected form; the server validates and creates the account; a regenerated session opens the dashboard.','Invalid fields or a duplicate email produce helpful errors. A rejected request does not create a partial account. Passwords are never repopulated into the form.','One account exists with a password hash; the learner is authenticated.'),
('UC02 Create a deck and flashcard','The learner is authenticated.','Create a deck with title, subject, description, and an allowed color; open it; add a question and answer with optional explanation; save; the server creates the card and its initial due progress record.','An empty title/question/answer is rejected. Another learner cannot select an owned deck by changing its ID.','The card is immediately due and appears in its owner’s deck.'),
('UC03 Complete a scheduled review','At least one owned card is due and the learner is authenticated.','Start a due session; read a question; attempt recall; POST Show answer; compare the answer; choose one rating; the server validates the nonce and owner, locks progress, computes the schedule, saves history, and advances or shows results.','A stale nonce gives no duplicate review. A removed or newly future-due card cannot be rated as due. Invalid ratings or unrevealed answers are rejected.','The accepted rating is recorded once; the next due date reflects the implemented rules.'),
('UC04 Practice deliberately','An owned deck contains cards; some may not be due.','Choose Practice all cards; reveal each answer and submit ratings; finish or exit the session; view the recorded activity.','Leaving early preserves only reviews already submitted. The application does not invent completed answers for unreviewed cards.','Practice history is stored while due time, ease, interval, and scheduled-review counters remain unchanged.'),
('UC05 Import a CSV deck','The learner owns the selected deck.','Open Import CSV; choose a UTF-8 file with question,answer and optional explanation headers; submit; validate size, rows, text, and fields; insert all accepted rows in one transaction.','Malformed headers, invalid UTF-8, empty mandatory fields, excess size, or excess rows reject the batch.','Either the complete validated batch is added or no imported cards are added.'),
('UC06 Configure a fresh local installation','The complete folder is in htdocs, Apache/MySQL run, and no private app configuration exists.','Open index.php; reach local setup; provide loopback host/port/database and administrator credentials; the server checks compatibility, creates tables and a dedicated identity, writes private settings exclusively, then opens registration.','Remote setup, CSRF failure, invalid settings, unrelated tables, missing privileges, or an existing configuration prevents unsafe setup.','The app uses its scoped identity and setup is unavailable until an operator explicitly changes private configuration.')]:
    start = len(story)
    sub(title);para('Preconditions: '+pre);para('Main flow: '+main);para('Alternatives: '+alternate);para('Postconditions: '+post)
    story[start:] = [KeepTogether(story[start:])]

chapter('System context and architecture')
para('BrainLoop is a layered, server-rendered monolith. A browser exchanges ordinary GET and POST requests with a PHP front controller. Controllers validate actions and delegate persistence to Store and scheduling to Scheduler. Reusable views render escaped HTML; CSS provides responsive presentation. MySQL is the authoritative persistent store. This combines client-server communication with an MVC-style separation and a repository-like data access component. It does not use a single-page application or an external backend service. [L06, PDF pp 8 to 12]')
d=Drawing(WIDTH,270)
box(d,145,225,210,45,['Learner browser','Semantic HTML and CSS'])
box(d,80,145,340,55,['PHP entry point and request controllers','Routing, sessions, CSRF, validation, authorization'])
box(d,24,65,140,55,['Views and helpers','Escaped server-rendered pages'],size=9)
box(d,183,65,135,55,['Scheduler','Pure rating-to-date rules'],size=9)
box(d,337,65,138,55,['Store and PDO','Prepared queries and locks'],size=9)
box(d,335,0,140,45,['MySQL or MariaDB','InnoDB and utf8mb4'],size=9)
arrow(d,250,225,250,200,'GET and POST');arrow(d,160,145,95,120);arrow(d,250,145,250,120);arrow(d,340,145,405,120);arrow(d,405,65,405,45,'SQL')
diagram('architecture',d,'Implemented component view. Controllers coordinate the request; the scheduler has no database dependency.')
table(['Layer','Actual source','Responsibility'],[
['Entry and infrastructure','index.php; public/index.php; app/bootstrap.php; app/core/urls.php','Start the application, discover the installation path, configure sessions, and dispatch routes.'],
['Request handling','app/controllers/*.php','Validate fields and HTTP actions, require authentication, handle PRG redirects, and select views.'],
['Persistence','app/models/Store.php; app/core/Database.php','Prepared SQL, scoped resource access, database initialization, transactions, and analytics.'],
['Business rules','app/services/Scheduler.php; LocalInstaller.php','Deterministic review rules and guarded one-time local provisioning.'],
['Presentation','app/views/layouts, partials, pages; public/assets/css','Reusable semantic pages, escaped content, responsive navigation, and local branding.']],[.17,.38,.45])
para('Architectural views answer different questions. The component view explains static responsibility; the deployment view explains where browser, Apache/PHP, and MySQL run; the review sequence explains runtime collaboration. This is consistent with the lecture’s multiple-view approach. [L06, PDF p 7]')

chapter('Data and database design')
para('Persistent data is held in six InnoDB tables using utf8mb4. Surrogate primary keys identify records; foreign keys and cascading deletion keep related card schedules and histories consistent. Emails are unique, each card has one progress row, and each accepted submission key is unique. The connection uses native prepared statements, a strict SQL mode, and a UTC session timezone.')
d=Drawing(WIDTH,320)
box(d,15,240,135,62,['users','PK id','Unique email'],size=9)
box(d,185,240,135,62,['decks','PK id / FK user_id','Title and subject'],size=9)
box(d,355,240,135,62,['flashcards','PK id / FK deck_id','Question and answer'],size=9)
box(d,165,105,155,75,['card_progress','Unique FK flashcard_id','FK user_id','Due date and schedule'],size=9)
box(d,345,105,155,75,['review_history','FK flashcard_id / user_id','Unique submission_key','Rating and review time'],size=9)
box(d,10,10,145,65,['login_attempts','Hashed identifier','Attempt time'],size=9)
arrow(d,150,270,185,270,'1 to many');arrow(d,320,270,355,270,'1 to many')
arrow(d,400,240,275,180,'1 to 1');arrow(d,445,240,445,180,'1 to many')
label(d,180,40,'Progress and history also reference the owner in users.',9,GRAY)
diagram('entity-relationships',d,'Entity relationship overview. login_attempts is an abuse-control table and has no user foreign key.')
sub('Normalization and deliberate redundancy')
para('Each table records one type of fact: account identity, deck metadata, card content, current schedule, a review event, or an abuse-control attempt. Questions and answers are not repeated across separate subject tables. The model avoids repeating deck titles in every card or storing a comma-separated list of cards in a user row. These choices support first normal form and dependencies organized around table keys.')
para('The owner identifier is also stored in progress/history, and current scheduling counters summarize accepted scheduled reviews. This is deliberate redundancy for scoped lookups and current-state access. It requires transactionally consistent writes and owner checks. It should not be described as a proof that every derived value is independently normalized. The application joins parent ownership when reading or changing a resource.')
sub('Indexes and lifecycle')
para('Indexes cover decks by owner and update time, cards by deck, progress by owner and due time, history by owner and review time, history by card, and login attempts by hashed identifier and time. Deleting a deck removes its cards, progress, and history through foreign keys. Analytics recalculate from the remaining history; deleted reviews do not continue contributing to totals.')
descriptions={
'id':'Surrogate primary key generated by the database.','full_name':'Validated learner display name, at most 80 characters.','email':'Normalized account email with a unique constraint.','password_hash':'One-way password hash; never a plaintext password.','created_at':'Creation timestamp persisted in UTC.','updated_at':'Most recent content/profile update timestamp in UTC.',
'user_id':'Owner reference to users.id; relevant relationships cascade on deletion.','title':'Validated deck title, at most 120 characters.','description':'Optional deck description, validated to at most 1500 characters.','subject':'Optional subject/category, at most 80 characters.','color':'One allowed seven-character hexadecimal deck color.','deck_id':'Reference to the parent deck; cards cascade when a deck is deleted.','question':'Nonempty front text; application limit 2000 Unicode characters.','answer':'Nonempty back text; application limit 5000 Unicode characters.','explanation':'Optional supporting context; application limit 5000 characters.','flashcard_id':'Reference to flashcards.id; unique in progress and repeatable in history.','review_state':'Current state: new, relearning, or review.','due_at':'Next scheduled review timestamp in UTC.','interval_days':'Current scheduling interval, including the intentional ten-minute step.','ease_factor':'Review multiplier, clamped by the service to 1.3 through 3.0.','repetition_count':'Consecutive successful scheduled reviews since the last Again.','total_reviews':'Number of scheduled review events; practice does not increment it.','last_rating':'Most recent scheduled rating, or null before review.','last_reviewed_at':'Most recent scheduled review timestamp, or null.','rating':'Recall rating: again, hard, good, or easy.','interval_before':'Scheduled interval before the recorded review.','interval_after':'Scheduled interval after review; equal to before for practice.','reviewed_at':'History event timestamp in UTC.','is_practice':'1 for intentional practice, otherwise 0.','submission_key':'Unique server-generated review key for duplicate prevention.','identifier':'Hashed login account/IP abuse-control identifier.','attempted_at':'Unix time of a recorded failed login attempt.'}
schema=(ROOT/'database/schema.mysql.sql').read_text(encoding='utf-8-sig')
for table_name,body in re.findall(r'CREATE TABLE IF NOT EXISTS\s+(\w+)\s*\((.*?)\)\s*ENGINE',schema,re.S|re.I):
    sub('Data dictionary '+table_name)
    rows=[]
    for line in body.splitlines():
        match=re.match(r'\s*(\w+)\s+((?:BIGINT|INT|TINYINT|VARCHAR|CHAR|TEXT|DATETIME|DOUBLE|DECIMAL)[^,]*?)(?:\s+(?:NOT NULL|DEFAULT|CHARACTER|PRIMARY|UNIQUE)|,|$)',line,re.I)
        if match and match[1] in descriptions:
            type_text=re.match(r'\s*\w+\s+([A-Z]+(?:\([0-9,]+\))?(?:\s+UNSIGNED)?)',line,re.I).group(1)
            rows.append([match[1],type_text,descriptions[match[1]]])
    table(['Column','SQL type','Purpose'],rows,[.24,.22,.54])

chapter('Interaction state and workflow models')
para('The system models focus on boundaries and decisions that affect behavior. A context model separates the learner, local operator, application, and database. Interaction models show a review transaction and the guard conditions around it. State modeling explains why rating is unavailable until reveal and how scheduling moves a card between states. [L05, PDF pp 3 to 4, 8, and 14 to 17]')
sub('Study activity flow')
d=Drawing(WIDTH,370)
for y,lines in [(315,['Start due review','Choose owned due cards']),(235,['Show question','Answer absent from HTML']),(155,['POST Show answer','Validate CSRF and session nonce']),(75,['POST recall rating','Validate owner, reveal state, and nonce'])]:box(d,100,y,300,48,lines,size=10)
for y in [315,235,155]:arrow(d,250,y,250,y-32)
box(d,100,0,300,48,['Commit schedule and history','Next queued card, or session results'],size=10)
arrow(d,250,75,250,48)
diagram('study-activity',d,'Study activity. After a commit, the application advances to the next queued card or the results page.')
sub('Scheduling state model')
d=Drawing(WIDTH,220)
box(d,15,135,130,55,['New','Due immediately'])
box(d,350,135,140,55,['Review','Successful interval'])
box(d,185,20,140,60,['Relearning','Again: due in 10 min'])
arrow(d,145,162,350,162,'Hard / Good / Easy')
arrow(d,80,135,205,80,'Again')
arrow(d,420,135,305,80);label(d,405,105,'Again',9,GRAY)
arrow(d,255,80,375,135);label(d,220,120,'Successful recall',9,GRAY)
diagram('scheduling-states',d,'Scheduling states are persisted. The temporary revealed/unrevealed state belongs to the PHP study session.')
sub('Runtime review sequence')
d=Drawing(WIDTH,315)
xs=[45,175,310,450]
for x,name in zip(xs,['Browser','Controller/session','Store/Scheduler','MySQL']):
    box(d,x-43,270,86,32,[name],size=8)
    d.add(Line(x,25,x,267,strokeColor=BORDER,strokeDashArray=[3,3]))
for y,fr,to,text in [(240,0,1,'POST rating + CSRF + nonce'),(210,1,2,'Validate session and owner'),(180,2,3,'Begin transaction / lock progress'),(150,3,2,'Current card schedule'),(120,2,2,'Compute next due interval'),(90,2,3,'Update progress and insert history'),(60,1,0,'303 redirect to next/result')]:
    if fr==to:label(d,xs[fr]+8,y,text,8)
    else:arrow(d,xs[fr],y,xs[to],y);label(d,(xs[fr]+xs[to])/2,y+6,text,7.5,GRAY,anchor='middle')
diagram('review-sequence',d,'Review sequence. The unique submission key and database transaction complement the session nonce.')
para('The server may retrieve a full card record internally, but answer and explanation fields are removed before the unrevealed study view is rendered. This is a server response guarantee, not a CSS hiding trick. A learner who inspects the initial HTML cannot retrieve a preloaded answer from that page.')

chapter('Implementation design and security')
sub('Request processing')
para('The root index.php supports an htdocs subfolder; the public entry point remains available for a dedicated document root. URL helpers derive the installation base and apply it consistently to navigation, forms, asset versions, redirects, and cookie paths. Rewrites expose the front controller and allowed static assets while private directories have deny rules.')
para('POST actions validate a CSRF token before state changes. Controllers parse scalar input, enforce length and identifier constraints, check authentication, and use Post Redirect Get after successful mutation. Password fields are never retained as old form values. Error rendering avoids exposing database credentials or raw stack traces.')
sub('Module responsibilities')
table(['Module','Implementation decision','Engineering reason'],[
['AuthController','password_hash/password_verify, regenerated sessions, login throttling, current-password checks','Centralize authentication and reduce credential handling across templates.'],
['DeckController','Owned resource lookup, validation, confirmation, CSV import/export','Keep request parsing and workflow feedback separate from SQL.'],
['StudyController','Server-side queue, reveal flag, nonce, ratings, exit/results','Ensure the browser cannot choose an unauthorized card or rate without reveal.'],
['Store','Native prepared SQL, ownership predicates, row locks, transactions','Give all routes a consistent data-integrity boundary.'],
['Scheduler','Pure deterministic function with a fixed-clock test interface','Make review rules explainable and testable independently of HTTP.'],
['LocalInstaller','Loopback guard, compatibility check, exclusive config creation, scoped identity','Make first-time setup approachable without storing administrator credentials.']],[.20,.42,.38])
sub('Threats and safeguards')
table(['Threat','Safeguard','Verification example'],[
['SQL injection','Native PDO parameters; fixed SQL identifiers; validated database names','SQL-like search text remains data and does not change result ownership.'],
['Cross-site scripting','Escape stored and submitted text through htmlspecialchars before HTML output','Markup-like question/search content appears as text.'],
['Cross-site request forgery','Session CSRF token on all state-changing forms','Missing/incorrect token returns a rejection without mutation.'],
['Direct object access','User ownership checked through Store queries and parent relationships','A second account cannot read/edit/delete/export another learner’s deck.'],
['Duplicate or stale reviews','Server nonce, revealed state, unique submission key, locked current schedule','Replay does not create a second accepted rating.'],
['Unsafe CSV content','Size/row/encoding validation, no executable upload storage, formula neutralization','Invalid import rolls back; dangerous export prefixes become literal text.'],
['Private file disclosure','Root and per-directory Apache restrictions; only allowed assets are served','Configuration, schemas, scripts, storage, tests, and internal public paths are blocked.']],[.23,.40,.37])
para('These controls support secure local operation, but they do not constitute an independent penetration test. A public deployment additionally requires maintained software, HTTPS, secure server permissions, access-controlled backups, and reviewed hosting configuration. Database administrator credentials are used only during approved setup and are never the normal learning account.')
para('The implementation lecture emphasizes interfaces, reuse, configuration, and appropriate design patterns. BrainLoop uses these ideas selectively; it does not add factories, observers, or a framework where they would introduce unnecessary complexity. [L07, PDF p 9, pp 10 to 13, and pp 15 to 16]')

chapter('Spaced repetition algorithm')
para('The scheduling service is simplified and SM-2-inspired; it is not advertised as the official SM-2 algorithm. New cards are due immediately. Ratings are learner judgments and may be inconsistent; the system uses them to schedule practice rather than claiming to measure memory directly.')
para('Let I be the prior interval in days, E the pre-review ease clamped to 1.3 through 3.0, and R the number of consecutive successful scheduled reviews since the last Again. The formulas below use the pre-review ease. Successful intervals are rounded up to whole days, kept at least one day, and capped at 36,500 days.')
table(['Rating','First success or R zero','R one','R two or more','Ease update'],[
['Again','10 minutes','10 minutes','10 minutes','max(1.3, E - 0.20)'],
['Hard','1 day','max(I + 1, 3)','max(I + 1, ceil(I x 1.2))','max(1.3, E - 0.15)'],
['Good','1 day','max(I + 1, 6)','max(I + 1, ceil(I x E))','Unchanged'],
['Easy','4 days','max(I + 1, 8)','max(I + 1, ceil(I x E x 1.3))','min(3.0, E + 0.15)']],[.12,.22,.19,.27,.20])
para('Again resets consecutive successes to zero and sets state relearning. A successful rating sets state review and increments consecutive successes. Every accepted scheduled review increments total_reviews and records last_rating and last_reviewed_at. Next due time is actual review time plus the new interval, not the previous due date.')
sub('Worked example')
para('For a new card reviewed at 15 September 2026 12:00 UTC, Good gives a one-day interval and a due date of 16 September at 12:00 UTC. Repeated Good ratings when due produce intervals 1, 6, 15, and 38 days at ease 2.5. Again then schedules a ten-minute relearning step. A subsequent successful review restarts the early progression.')
para('A changed successful rating cannot shorten the interval through the second-step rule: Easy on a new card gives four days, so a following Hard gives five days through max(I + 1, 3). Practice creates a history event with equal before/after intervals and leaves every scheduling field unchanged. See docs/SCHEDULING.md for exact service rules and tests.')

chapter('Interface and learning experience')
para('The interface uses the BrainLoop purple and teal identity with strong text contrast, readable system fonts, consistent spacing, rounded surfaces, and local original SVG icons. The primary task is to create a useful question, attempt recall, and return to due material. Decorative product previews on the landing page are explicitly marked as sample data.')
para('The authenticated dashboard reads its totals from MySQL. A new learner sees real zeros and onboarding actions rather than fabricated progress. Due work and cards reviewed today are shown with labels explaining the calculation. Deck cards show subject, description, card counts, due counts, and an operational progress indicator.')
para('The study view emphasizes the question, deliberate answer reveal, and four descriptive rating controls. Keyboard users can activate the same HTML buttons. Native details/summary controls support answer inspection outside study. Mobile navigation adapts to the available screen rather than requiring JavaScript or simply shrinking the desktop sidebar.')
sub('About and team presentation')
para('About uses the group photograph supplied by the team and presents all four people without mapping faces to individual names. Separate cards preserve exact names and student IDs with the confirmed specialties. The global footer contains brand and navigation information without member names or IDs, reducing repetition and keeping team details in their appropriate page.')
sub('Accessibility and content conventions')
bullets(['Use one main heading per page, logical subordinate headings, landmarks, and a skip link.','Associate labels and error text with inputs; preserve safe input after validation failures.','Provide visible focus, adequate target sizes, and text labels for rating/color states.','Describe chart values in text; do not make color the only carrier of meaning.','Respect prefers-reduced-motion and keep the full core workflow functional without JavaScript.','Review long titles, multilingual card text, zero activity, validation errors, and narrow layouts.'])

chapter('Verification and validation strategy')
para('Verification checks conformance to the specification; validation checks support for the learner’s intended activity. Scheduler, MySQL, HTTP, Apache installation, and browser checks follow the lecture progression from component testing through system and acceptance work. [L02, PDF pp 10 to 11; L08, PDF pp 7 to 14 and 20 to 21]')
table(['Level','Focus','Examples'],[
['Unit','Independent deterministic rules','All ratings, early/subsequent intervals, lapse reset, ease bounds, UTC conversion, invalid rating.'],
['Database and model','Queries, constraints, ownership, consistency','Unique email/progress/key; foreign keys; transaction rollback; private search; practice preservation.'],
['Integration and HTTP','Collaborating controllers, sessions, forms, and persistence','Registration/login/logout, CRUD, reveal, rating, duplicate submissions, settings, CSV.'],
['System and deployment','The copied application in real Apache/MySQL','Fresh folder setup, index entry, subfolder links/cookies, protected files, complete review.'],
['User acceptance','A learner performs meaningful tasks','Create a deck/card, complete review, interpret due work, export a deck, and use a narrow screen.']],[.20,.35,.45])
sub('Test design')
para('Equivalence partitions separate valid and invalid inputs. Boundaries include empty/maximum text, invalid IDs, one-MiB uploads, 500-card imports, due_at equal to now, and interval/ease caps. Negative cases change owner IDs, omit CSRF, replay ratings, and submit markup/SQL-like text. Scheduler checks use a fixed clock. [L08, PDF pp 7 to 10]')
para('Refactoring should preserve behavior. Meaningful failing cases reproduce defects and remain as regression checks. The lecture’s test-first approach informs this practice; strict TDD throughout the original implementation is not claimed. [L03, PDF pp 8 to 11; L08, PDF pp 15 to 16]')
story.append(PageBreak())
sub('Observed local results 25 November 2026')
para('The final local checks used Windows, PHP 8.2.12, PDO MySQL, and XAMPP MariaDB 10.4.32. Oracle MySQL and public HTTPS hosting were not exercised. Results below are observed local checks, while the acceptance cases in the following chapter remain the criteria for the planned classroom demonstration.')
table(['Test group','Latest recorded result','Evidence'],[
['PHP syntax',METRICS.get('syntax','See current verification record'),'Syntax checks across executable source files.'],
['Scheduler/model/security',METRICS.get('model','See current verification record'),'tests/run.php using isolated MySQL data.'],
['HTTP at host root',METRICS.get('http_root','See current verification record'),'tests/http.php with an isolated schema/server.'],
['HTTP in copied folder',METRICS.get('http_mount','See current verification record'),'tests/http.php --subdirectory.'],
['Actual XAMPP fresh copy',METRICS.get('apache','See current verification record'),'tests/apache-copy.php, with owned disposable fixtures.'],
['Browser review',METRICS.get('browser','See current verification record'),'Representative public/private pages, About photograph, footer, and responsive layouts.']],[.28,.29,.43])
para('Test results belong to a specific source version and local environment. The verification record identifies the run date and limits. No fabricated coverage percentage, load result, classroom acceptance sign-off, or hosted CI run is reported. Presentation acceptance on 8 December remains a planned team activity.')
sub('Reproducing the checks')
para('From the project folder, run the commands below with Apache and MySQL already available for the final Apache check. Database tests require separate local administrator test credentials to create and remove isolated schemas and accounts; they must never target a shared production server. See docs/TESTING.md for environment variables and prerequisites.')
code('& "C:\\xampp\\php\\php.exe" tests/run.php\n& "C:\\xampp\\php\\php.exe" tests/http.php\n& "C:\\xampp\\php\\php.exe" tests/http.php --subdirectory\n& "C:\\xampp\\php\\php.exe" tests/apache-copy.php')
para('Each integration runner creates randomly named fixtures and removes only its owned temporary schema and account. Browser verification used a separate temporary MySQL schema, learner, and local PHP server. Ordinary application credentials and study records were preserved. The existing Apache and MySQL services were left running.')

chapter('Acceptance cases and traceability')
table(['Case','Scenario','Expected result','Requirements'],[
['AC01','Copy full folder into htdocs and open index.php','Home or guarded first-time setup loads with local assets.','FR14, FR16'],
['AC02','Register valid and duplicate accounts','One hashed account per email; duplicate is rejected.','FR01'],
['AC03','Use a second account to change a deck/card ID','No unauthorized read, edit, delete, import, export, or review.','FR02 to FR06'],
['AC04','Create and edit multiline card content','Escaped content is retained and rendered clearly.','FR04, NFR03'],
['AC05','Inspect initial study response before reveal','Answer and explanation are absent from its HTML.','FR08'],
['AC06','Reveal and rate Good, then replay the POST','One history event and correct future due date.','FR09, NFR02'],
['AC07','Start due review after scheduling future cards','Future-due cards are omitted.','FR07'],
['AC08','Practice a future card','History grows but the complete scheduling record is unchanged.','FR10'],
['AC09','Import valid/invalid and oversized CSV','Complete valid batch or a safe rejection with no partial import.','FR05'],
['AC10','Export formula-leading text','Owned CSV is downloaded and leading formulas are neutralized.','FR06'],
['AC11','Review on consecutive UTC dates','Distinct-day current/longest streak calculations match recorded history.','FR11'],
['AC12','Check About and the global footer','Provided photo and exact team details on About; no names/IDs in footer.','FR15'],
['AC13','Complete the workflow using keyboard and narrow viewport','Controls remain reachable with visible focus and readable content.','NFR03 to NFR05']],[.10,.31,.43,.16])
sub('Requirement to implementation mapping')
table(['Requirements','Principal implementation','Evidence location'],[
['FR01, FR13','AuthController; Store user/profile/password methods','HTTP authentication/settings checks and password-hash checks.'],
['FR02 to FR06, FR12','DeckController; Store; validation/escaping helpers','CRUD, ownership, CSV, search, and rollback checks.'],
['FR07 to FR10','StudyController; Scheduler; Store review transaction','Fixed-clock scheduler cases and HTTP study/retry/practice checks.'],
['FR11','Store stats/daily/ratings/activity methods; analytics views','Real-history, unique-card, date-bucket, and streak cases.'],
['FR14, FR16','LocalInstaller; root entry; URL helpers; Apache rules','Mounted HTTP suite and real Apache fresh-copy checks.'],
['FR15','About view; team photograph; footer partial; shared layout','Image HTTP check and browser/footer inspection.']],[.22,.41,.37])
para('Traceability helps assess a requested change before implementation: identify affected requirements, modules, test cases, documentation, and responsibilities. Requirements management and impact analysis support this practice. [L04, PDF pp 26 to 28; L09, PDF pp 5 to 9]')

chapter('Planned timeline and milestones')
start=datetime.date(2026,9,15);end=datetime.date(2026,12,8)
para('The planned baseline runs from 15 September through 8 December 2026, an inclusive span of '+str((end-start).days+1)+' calendar days. It allocates work by deliverable and review point. The dates are planning targets, including those before this report date; they are not reconstructed claims of completed work or attendance. The final milestone is the class presentation and submission on 8 December.')
schedule=[
('15 to 21 Sep','Initiation and feasibility','Problem statement, objectives, scope, team agreement','Uttam; all members review'),
('22 to 28 Sep','Requirements','User stories, FR/NFR baseline, acceptance cases','Uttam and Shraddha; team review'),
('29 Sep to 5 Oct','Analysis and modeling','Use cases, context/interaction models, draft data model','Uttam and Suraj'),
('6 to 12 Oct','Architecture and design','Layer boundaries, MySQL schema, wireframes, style system','Uttam, Manisha, Suraj'),
('13 to 19 Oct','Foundation increment','Routes, public pages, registration/login, protected shell','Uttam and Suraj; Manisha styles'),
('20 to 26 Oct','Content increment','Deck/card CRUD, owner constraints, form feedback','Uttam and Suraj; Shraddha tests'),
('27 Oct to 2 Nov','Study increment','Reveal flow, ratings, scheduler, results, retry protection','Uttam; Suraj/Manisha interface; Shraddha tests'),
('3 to 9 Nov','Progress and exchange','Analytics, search, settings, CSV import/export','Uttam and Suraj; Shraddha tests'),
('10 to 16 Nov','System integration','MySQL configuration, htdocs routing, setup, security review','Uttam and Shraddha'),
('17 to 23 Nov','Quality refinement','Responsive interface, accessible labels, negative regression','Manisha, Suraj, Shraddha'),
('24 to 30 Nov','Documentation and acceptance preparation','Report, traceability, actual test record, team review','Uttam leads; all supply evidence'),
('1 to 7 Dec','Release and rehearsal','Feature freeze, clean-PC trial, backups, slides/demo rehearsal','All members; Uttam integrates'),
('8 Dec','Presentation and submission','Present, demonstrate, answer questions, submit approved package','All members')]
table(['Planned dates','Phase','Deliverable','Responsible area'],schedule,[.18,.22,.35,.25])
d=Drawing(WIDTH,355)
left=165;cols=13;cell=(WIDTH-left-8)/cols
for i in range(cols):label(d,left+i*cell+cell/2,335,'W'+str(i+1),8,GRAY,anchor='middle')
for row,(dates,phase,deliver,owner) in enumerate(schedule):
    y=310-row*23
    for i in range(cols):d.add(Rect(left+i*cell,y-4,cell,18,fillColor=None,strokeColor=BORDER,strokeWidth=.3))
    label(d,0,y+1,phase[:30],8.5)
    d.add(Rect(left+row*cell+2,y-2,cell-4,14,fillColor=PURPLE if row<12 else TEAL,strokeColor=None))
label(d,0,3,'W13 is the presentation milestone on 8 December; all bars are planned.',8.5,GRAY)
diagram('planned-timeline',d,'Planned weekly delivery sequence from 15 September to 8 December 2026. Integration and review continue across phases.')
sub('Milestone exit criteria')
table(['Target','Milestone','Exit evidence'],[
['21 Sep','Scope agreed','Problem, audience, boundaries, and team responsibilities reviewed.'],
['28 Sep','Requirements baseline','FR/NFR and acceptance cases checked for consistency and feasibility.'],
['12 Oct','Design baseline','Architecture, data relationships, wireframes, and security decisions reviewed.'],
['2 Nov','Core learning path','An owned card can be created, revealed, rated, and scheduled.'],
['23 Nov','Integrated quality baseline','Full workflow, ownership, setup, responsive layouts, and regression reviewed.'],
['30 Nov','Documentation review','Report and traceability checked against implementation and lecture references.'],
['7 Dec','Presentation readiness','Clean installation, complete test record, backup, and rehearsal completed as planned.'],
['8 Dec','Class delivery','Approved source/documentation package submitted and live demonstration presented.']],[.16,.28,.56])

chapter('Team contributions and responsibility allocation')
para('The team provided the primary contribution areas below. The detailed work allocation formalizes those areas into responsibilities and expected artifacts; it does not invent individual hours, commit counts, meeting attendance, or task-completion dates.')
for member in META['team']:
    sub(member['name']+' '+member['student_id']);para(member['role']+'. '+member['contribution'])
table(['Member','Detailed responsibility allocation','Artifacts or review evidence'],[
['SHRESTHA UTTAM','Coordinate scope and integration across all parts; design PHP backend and MySQL relations; implement/auth-review sessions, scheduling, queries, setup, and security; manage GitHub workflow and the final documentation package.','Controllers, Store/Database, Scheduler integration, schema/setup, repository guidance, report, and integration review.'],
['THAPA MANISHA','Develop the CSS design system, page composition, typography, spacing, color treatments, responsive breakpoints, and visual consistency; review focus/contrast and the supplied photo presentation.','Stylesheets, responsive interface review, About/photo layout, component styling, and visual defect corrections.'],
['B K SURAJ','Develop semantic page markup and reusable frontend templates; connect forms/navigation to PHP routes; implement deck/card/study/search/settings presentation and meaningful validation/empty states.','HTML/PHP view templates, base-aware links/actions, labeled forms, reusable layout, and frontend integration review.'],
['KHAND THAKURI SHRADDHA','Develop functional and acceptance scenarios; exercise boundary/negative cases, ownership isolation, reveal/review behavior, MySQL installation, CSV exchange, and responsive regression; record and retest defects.','Test cases, test execution/verification records, defect notes, acceptance checklist, and presentation demonstration checks.']],[.22,.48,.30])
photo=ROOT/'public/assets/images/team-photo.jpg'
if photo.exists():
    story.append(Image(str(photo),width=WIDTH*.85,height=WIDTH*.85*2/3,hAlign='CENTER'))
    para('The four project members in the photograph supplied by the team. Names are listed separately; image positions are not used to identify individuals.','Caption')
sub('Review and accountability matrix')
table(['Activity','Uttam','Manisha','Suraj','Shraddha'],[
['Scope and requirements','A/R','C','C','C'],['CSS and visual design','A','R','C','C'],['Frontend templates','A','C','R','C'],['Backend and MySQL','A/R','C','C','C'],['Test planning and execution','A','C','C','R'],['Documentation and GitHub','A/R','C','C','C'],['Class presentation','A/R','R','R','R']],[.40,.15,.15,.15,.15])
para('A means accountable, R responsible, and C consulted. Each activity has one accountable team lead. Shared review does not imply that every member implemented every module; it provides a clear integration path and a way to catch defects across boundaries.')

chapter('Risk management maintenance and change control')
table(['Risk','Consequence','Mitigation','Owner'],[
['Database configuration or privilege failure','Fresh setup or testing cannot connect/create tables or accounts.','Use sanitized diagnosis, verify XAMPP service/port, preserve configuration and backups, and obtain approval before changing shared server system tables.','Uttam'],
['Late scope growth','Core acceptance and rehearsal displaced by optional features.','Keep a prioritized baseline; defer unrelated sharing, email, and gamification features.','Uttam with team'],
['Responsive or inconsistent interface','A required form/control becomes hard to use on a small screen.','Shared CSS primitives and viewport/keyboard checks; record and retest visual defects.','Manisha and Suraj'],
['Unauthorized or duplicate review','Private data leaks or the learning schedule is credited twice.','Owner predicates, CSRF, nonce, row locking, unique keys, and negative regression cases.','Uttam and Shraddha'],
['Unsafe credentials or backup handling','Private data is included in source hosting or exposed through HTTP.','Ignored private files, scoped identity, deny rules, protected backups, and review before Git commit.','Uttam'],
['Presentation environment failure','Class demonstration is delayed or cannot finish.','Rehearse a clean installation, keep an offline source/report package and exported sample deck, verify both XAMPP services before class.','All members']],[.23,.24,.39,.14])
para('Corrective maintenance fixes defects, adaptive maintenance responds to environment changes, and perfective maintenance improves maintainability or usability. The MySQL and htdocs deployment changes are examples of adapting the project to its operating environment. Interface refinements and clearer documentation improve usability and support. These distinctions follow Software Evolution. [L09, PDF p 20 and pp 28 to 29]')
sub('Change procedure')
bullets(['Record the requested behavior and the affected requirement IDs.','Review the impact on architecture, data, security, tests, documentation, and planned dates.','Assign an implementation owner and a reviewer; preserve configuration and user data.','Implement a small coherent change and run the relevant automated/manual checks.','Update the verification record and user instructions; integrate only after acceptance.'])
para('Useful maintenance indicators include unresolved defects, repeated failures, changed requirements, test outcomes, and modules with frequent difficult edits. Do not invent velocity, code coverage, or reliability statistics without measurement. [L09, PDF pp 5 to 9 and 23 to 24]')

chapter('Installation operation and data protection')
sub('Local XAMPP procedure')
bullets(['Install XAMPP with PHP 8.2+ and verify that PDO MySQL is enabled.','Copy the complete BrainLoop folder to C:\\xampp\\htdocs\\BrainLoop, including the root index.php and .htaccess files. Avoid an extra nested folder.','Start Apache and MySQL in the XAMPP Control Panel.','Open http://localhost/BrainLoop/ or http://localhost/BrainLoop/index.php through the browser, not as a file URL.','For a fresh copy, complete the loopback-only setup form. Use the actual local database administrator and port; a blank password is appropriate only when that local account has no password.','After setup, register an ordinary BrainLoop learning account. The database administrator and learning account are different identities.','Create a deck and card, complete a review, and inspect analytics to verify the installation.'])
para('The browser installer creates a separate database user restricted to the selected schema and saves only that application identity in app/config.local.php. Existing private configuration is preserved when source files are updated. A copied source folder does not copy or clear a running MySQL database. The README includes browser and manual phpMyAdmin setup, extension checks, troubleshooting, backup/restore, and development-server alternatives.')
sub('Operational checks')
table(['Symptom','Check','Action'],[
['Page cannot be reached','Apache running and correct localhost port','Start Apache and use the port configured in XAMPP.'],
['Database connection fails','MySQL running, pdo_mysql enabled, port and private identity correct','Run the sanitized diagnosis command; do not print private credentials.'],
['Not found after a navigation click','Whole folder structure and root .htaccess present','Use the root index entry and preserve the installation base; avoid nested copies.'],
['Private file gives 403','The file is a config/schema/script/storage path','Expected protection; use the browser application or local file system as appropriate.'],
['Fresh setup reports incompatible tables','The chosen database contains unrelated or incompatible data','Choose a new database; do not delete another application’s tables.'],
['GRANT or shared permission-table error','XAMPP/MariaDB system-table health','Back up and seek operator approval for server repair; changing application SQL alone does not repair a corrupt system table.']],[.25,.34,.41])
sub('Backups and restore')
para('Back up the MySQL schema and data before release or risky maintenance. Keep backups outside htdocs and out of Git. Use a password prompt rather than embedding credentials in commands or screenshots. For an InnoDB dump, --single-transaction supports a consistent snapshot; an operator should verify the resulting file and test a restore into a separate database. Restore through phpMyAdmin Import or an approved MySQL client workflow after confirming the target and retaining the current backup.')
code('& "C:\\xampp\\mysql\\bin\\mysqldump.exe" --user=root --password --single-transaction --result-file="C:\\Backups\\brainloop.sql" brainloop')
para('For public hosting, use a maintained PHP/MySQL server, HTTPS, secure cookies, least-privilege service permissions, protected backups, and the public directory as the document root. GitHub hosts source collaboration; GitHub Pages cannot execute PHP. A production hosting service and domain are not claimed by this project.')

chapter('Presentation and submission plan')
para('The delivery milestone is 8 December 2026. The following is a suggested twelve-minute sequence; the team should adjust it to the class time limit. Speaker ownership reflects the confirmed work areas and gives every member a substantive part.')
table(['Time','Speaker','Content and demonstration'],[
['0:00 to 1:30','Uttam','Problem, objectives, scope, planned process, and what the team built.'],
['1:30 to 3:00','Manisha','Design system, responsive layout, accessibility decisions, and About/photo presentation.'],
['3:00 to 5:30','Suraj','Learner path: registration/login, deck/card forms, navigation, search, and content exchange.'],
['5:30 to 8:00','Uttam','Architecture, MySQL relationships, owner checks, review reveal/rating, and the next due date.'],
['8:00 to 10:00','Shraddha','Test levels, negative cases, duplicate review prevention, actual verification evidence, and known limits.'],
['10:00 to 12:00','All members','Summary of contributions, maintenance priorities, and questions.']],[.19,.20,.61])
sub('Suggested presentation outline')
para('Cover the learner problem; scope and requirements; the September to December process plan; architecture and MySQL; interface design; the live recall workflow and scheduler; test evidence and privacy controls; and team contributions, maintenance, and submission status.')
sub('Live demonstration checklist')
bullets(['Before class: confirm Apache/MySQL, exact URL, browser access, screen scaling, and a backup.','Prepare one clearly labeled sample deck and a small CSV; do not invent study history or expose real passwords.','Show a question with the answer absent, reveal it, rate recall, and show the changed schedule and history.','Demonstrate one meaningful rejected input or ownership/security test using controlled sample accounts.','Keep a sanitized screenshot set and PDF report as an offline fallback; explain a fallback honestly rather than presenting screenshots as a live running system.'])
sub('Submission package')
para('Include the approved source folder, root index and Apache rules, MySQL schema, README, project report, planned timeline, contribution allocation, test/verification record, license, and sanitized screenshots if required by class. Exclude private database credentials, session files, runtime databases, raw backups, personal study records, and unlicensed lecture-file copies. Verify the clean package using the fresh-copy test before the planned 7 December release freeze.')

chapter('Lecture references and application mapping')
para('References use physical PDF page numbers beginning at one, because the supplied files contain multiple slides on a page and slide footer numbering is not always a reliable locator. Concepts are paraphrased and applied to BrainLoop; lecture text and diagrams are not reproduced as a substitute for the original resources.')
references=[
('L01','SE_L01.pdf','Introduction',20,'Quality attributes and professional responsibility','PDF p 5 and pp 10 to 12','Project objectives, quality constraints, ethical/privacy responsibilities.'),
('L02','SE_L2.pdf','Software Processes',20,'Process models, incremental delivery, and verification/validation','PDF pp 3 to 7, 10 to 11, and 15 to 16','Incremental plan and multiple verification/validation activities.'),
('L03','SEL03.pdf','Agile Software Development',23,'User stories, refactoring, test-first practices, and Scrum concepts','PDF pp 7 to 15','Small backlog items, iterative review, regression, and explicit process limits.'),
('L04','SEL04.pdf','Requirements Engineering',30,'Functional/nonfunctional requirements, specification, validation, change','PDF pp 5 to 9 and 18 to 28','Requirements baseline, acceptance cases, traceability, and change procedure.'),
('L05','SE_L05.pdf','System Modeling',21,'Context, use case, sequence, class, and state modeling','PDF pp 3 to 4 and 6 to 17','System boundary, learner interactions, logical data relationships, and scheduling states.'),
('L06','SE_L06_ARCHITECTURAL+DESIGN.pdf','Architectural Design',20,'Views, MVC, layers, repository, client-server','PDF pp 7 to 12','Layered server-rendered architecture and actual component/runtime/deployment concerns.'),
('L07','SE_07_Design+and+Implementation.pdf','Design and Implementation',21,'Interfaces, design patterns, configuration management, licensing','PDF p 9, pp 10 to 16, and p 20','Simple module contracts, version control discipline, reusable templates, and MIT licensing.'),
('L08','SE_ch_8_Software+Testing.pdf','Software Testing',22,'Unit, interface, system, TDD, and user/acceptance testing','PDF pp 7 to 16 and 20 to 21','Test levels, boundaries, real HTTP/Apache checks, and planned classroom acceptance.'),
('L09','SEL09.pdf','Software Evolution',31,'Change impact, maintenance, metrics, refactoring','PDF pp 5 to 9, 20, 23 to 24, and 28 to 29','Risk/change management, maintainability, and evidence-based future improvement.')]
for rid,filename,title,pages,concept,anchors,application in references:
    sub(rid+' '+title)
    para(filename+'; '+str(pages)+' physical PDF pages. Relevant locations: '+anchors+'.','SmallBody')
    para('Concepts: '+concept+'. Application: '+application)
para('Detailed evidence and concept notes are retained in docs/LECTURE_MAPPING.md and docs/lecture-analysis.json. The original supplied PDFs remain in the team’s local course-material locations; they are not bundled into the application or automatically published.')

chapter('Conclusion and future improvement')
para('BrainLoop connects a focused learner workflow to a transparent implementation: private accounts and content, a deliberate question/reveal/rating sequence, deterministic scheduled reviews, and analytics calculated from MySQL history. Its PHP modules, ownership boundaries, schema constraints, and tests make the implementation explainable in class rather than a collection of static screens.')
para('The delivery plan concentrates on the existing scope, complete installation instructions, verified data handling, accessible presentation, and participation by all four members. The class presentation and submission on 8 December remain planned milestones. Future work should follow stakeholder feedback and evidence: investigate scheduling usability, measure performance with a documented dataset, improve recovery operations, and conduct a formal accessibility/security review before a public deployment.')

doc=Report(str(DOCS/'BrainLoop_Project_Report.pdf'),pagesize=A4,leftMargin=48,rightMargin=48,topMargin=51,bottomMargin=45,title='BrainLoop Software Engineering Project Report',author='BrainLoop project team',subject='Requirements design implementation testing team responsibilities and planned delivery')
doc.addPageTemplates(PageTemplate(id='report',frames=[Frame(48,45,WIDTH,A4[1]-96,id='normal',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=page_decoration))
doc.multiBuild(story)
(DOCS/'PROJECT_REPORT.md').write_text('\n'.join(md),encoding='utf-8')
plan_md=['# BrainLoop Planned Project Schedule\n','Baseline: 15 September to 8 December 2026. All dates below are planned targets, not a historical completion log.\n','| Planned dates | Phase | Deliverable | Responsibility |','| --- | --- | --- | --- |']
plan_md += ['| '+' | '.join(row)+' |' for row in schedule]
plan_md += ['\n![Planned timeline](assets/planned-timeline.svg)\n','Presentation and submission: **8 December 2026**. Planned rehearsal and release freeze: **1 to 7 December 2026**.']
(DOCS/'PROJECT_PLAN.md').write_text('\n'.join(plan_md),encoding='utf-8')
team_md=['# BrainLoop Team Contributions\n','Primary contribution areas were supplied by the team. Detailed module responsibility and review allocation are described in the project report; no individual hours, commit totals, or completion dates are invented.\n','| Member | Student ID | Role | Contribution area |','| --- | --- | --- | --- |']
team_md += ['| '+m['name']+' | '+m['student_id']+' | '+m['role']+' | '+m['contribution']+' |' for m in META['team']]
(DOCS/'TEAM_CONTRIBUTIONS.md').write_text('\n'.join(team_md)+'\n',encoding='utf-8')
print('Built PDF report, Markdown source, planned timeline, contribution record, and five vector diagrams.')

