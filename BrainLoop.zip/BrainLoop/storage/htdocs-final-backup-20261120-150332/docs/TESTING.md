# Verification guide

Report only checks actually executed. Automated tests do not substitute for visual inspection, and this project does not claim a formal accessibility or penetration-testing audit.

## Automated checks

`php tests/run.php` explicitly selects a separate in-memory SQLite database, even though normal application configuration defaults to MySQL/MariaDB. It covers deterministic scheduling, every rating and key boundaries, UTC conversion, leap-day behavior, escaped output, text/ID validation, schema setup, foreign keys, case-insensitive email uniqueness, parameterized queries, transactional rollback, cascading deletion, ownership isolation, search, scheduled review persistence, duplicate submissions, future-due exclusion, practice preservation, real analytics/streak calculations, and login throttling.

Run it from the project root:

```powershell
php tests/run.php
php tests/http.php
```

Exercise the same checks against the real MySQL/MariaDB server using `--mysql`:

```powershell
$env:BRAINLOOP_TEST_DB_HOST = "127.0.0.1"
$env:BRAINLOOP_TEST_DB_PORT = "3306"
$env:BRAINLOOP_TEST_DB_USER = "root"
# Set BRAINLOOP_TEST_DB_PASSWORD privately if required by this test administrator.
php tests/run.php --mysql
php tests/http.php --mysql
php tests/http.php --mysql --subdirectory
```

Test administrator credentials are separate from application credentials and need permission to create/drop temporary databases and users. The runners generate a database name matching `brainloop_test_` plus random hex characters and a separate scoped `bl_test_...` user with a random nonempty password. They override all application database settings for their test process and drop only that generated database/user on shutdown. This also keeps the HTTP application on a scoped identity rather than an administrator. They never run fixtures against the normal `brainloop` database. `BRAINLOOP_TEST_DRIVER=mysql` is an alternative to the command option. Without either option, SQLite is always selected explicitly.

`--subdirectory` mounts the project root entry point at `/BrainLoop/` through a fixture router. It runs the same authentication, CRUD, study, CSV, settings, and security workflow, checks raw redirects and rendered links remain inside the mount, and checks `/BrainLoop/index.php` opens the application. Combine it with `--mysql` for MariaDB or use it alone for isolated SQLite. The fixture simulates routing; actual Apache `.htaccess` behavior must also be verified on the installed XAMPP copy.

Check PHP syntax using the command in `README.md`. The GitHub Actions matrix runs PHP 8.2, 8.3, and 8.4 and provisions an isolated MariaDB service for the `--mysql` suites. A future CI run must not be described as already passed merely because its workflow file exists.

`tests/http.php` starts a separate PHP development server on a dynamically allocated local port and uses native PHP HTTP streams and cookie jars. It exercises actual pages and forms: registration/login/logout, CSRF, CRUD and ownership, answer withholding/reveal/rating, duplicate reviews, due-only/practice behavior, profile/password updates, CSV imports and formula-safe export, and protected source paths. A DOM-based crawl checks real public/private page anchors, linked assets, favicon delivery, and absence of rendered scripts/event handlers using GET requests only. It needs `proc_open`, `allow_url_fopen`, DOM, and the PDO driver for the selected backend in CLI PHP. The suite stops its own server and removes its own temporary data. HTTP fixtures use a temporary SQLite file by default or a generated MySQL/MariaDB database with `--mysql`.

## Functional checks

Use two fresh accounts that you own, without private study material.

| Area | Expected verification |
| --- | --- |
| Public pages | Home, Features, How It Works, About, Privacy, Terms, and custom 404 render; navigation and local assets load |
| Drop-in XAMPP copy | A complete folder at `C:\xampp\htdocs\BrainLoop` opens at `/BrainLoop/` and `/BrainLoop/index.php`; no extra `public/` URL or virtual host is needed |
| First-run setup | A fresh local copy without private configuration offers setup, validates database credentials, writes private configuration, and then disables repeat installation; preserve existing configuration/data when updating |
| Registration | Valid account creates; malformed input and duplicate/case-variant email fail; password is stored as a hash |
| Login/logout | Incorrect credentials fail; valid login regenerates session ID; logout requires POST; private routes redirect after logout |
| Decks | Create, view, subject filter, title search, edit, confirm deletion, and cascade removal work |
| Cards | Add, multiline display, edit, search question/answer, and confirmed deletion work |
| Ownership | Account B cannot read, edit, delete, export, import, or review resources belonging to account A by changing IDs |
| Study | Initial HTML contains no card answer; reveal POST displays it; rating advances card and saves schedule/history |
| Retry | Refresh/resubmit the same rating request; history and counters do not double |
| Completion | Finished and exited sessions show honest reviewed totals and rating distribution |
| Due logic | New cards appear; future cards are excluded; Again returns only after its short step becomes due |
| Practice | Future cards can be deliberately practiced; due_at, ease, repetition count, and scheduled-review count stay unchanged |
| Analytics | Stats start at zero; real review events update totals, unique cards today, ratings, and UTC activity |
| Settings | Profile edits persist; email change and password change require valid current credentials; duplicate emails fail |
| CSV | Valid UTF-8 import creates cards; oversized, malformed, empty, and excessive-row files fail safely; formula-leading export cells are neutralized |
| Security | Missing/invalid CSRF fails; SQL-like input is data; HTML is escaped; invalid IDs produce friendly responses |
| Routes | Wrong HTTP methods fail; no page serves source, configuration, storage, or arbitrary files |

## Responsive and keyboard checks

Inspect the homepage, login/register, dashboard, deck gallery, long deck/card content, settings, analytics, and study session at widths **375, 768, 1024, and 1440 CSS pixels**. Confirm no horizontal page overflow, clipped text, overlapping actions, or inaccessible form controls. The mobile app navigation should be usable without JavaScript.

Use Tab and Shift+Tab to reach all controls, confirm visible focus, activate buttons with the keyboard, open native details/summary controls, and complete a study session. Ensure inputs have labels, validation messages identify the error, status messages are announced, and progress/rating data has text equivalents. Enable the operating system's reduced-motion preference and inspect animation behavior.

## Portfolio screenshots

Capture the landing page, dashboard, deck detail, answer-reveal study page, analytics, and a 375px mobile page. Use a test account and clearly sample material. Do not publish email addresses, session IDs, private notes, or browser autofill information.

Save selected screenshots under a deliberately created `docs/screenshots/` directory for local review. That directory is ignored by default to keep automated/test captures out of source. If you intentionally add sanitized portfolio screenshots, force-add only the selected files after inspecting them and link them in `README.md`. Do not add fake screenshot links or images that do not exist.
